// -*- coding: utf-8 -*-
/**
 * RXcoderapp 藥局智慧小幫手系統 - 全域授權狀態與 OTA 自動升級模組
 * 製作人：施淳豪 (Chun-Hao Shih)
 * 版權所有 © 2026 施淳豪. All Rights Reserved.
 */

let g_licenseStatus = null;

// ==========================================
// 1. 授權狀態初始化與頂部徽章更新
// ==========================================
async function initLicenseStatus() {
  try {
    const res = await fetch('/api/license/status');
    const data = await res.json();
    g_licenseStatus = data;

    updateLicenseBadges(data);
    updateAboutPageLicense(data);
    updateLicensedPharmacyTitle(data);

    // 如果試用期已結束或時間篡改，鎖定寫入按鈕
    enforceLicenseRestrictions(data);
  } catch (err) {
    console.warn('[License] 讀取授權狀態失敗:', err);
  }
}

function updateLicensedPharmacyTitle(data) {
  const navTitle = document.getElementById('navbar-pharmacy-title');
  if (!navTitle) return;

  if (data.is_licensed && data.customer && data.customer !== '試用使用者' && data.customer !== '授權藥局' && data.customer !== '示範藥局') {
    navTitle.textContent = data.customer;
    const pageTitle = document.getElementById('page-title');
    if (pageTitle) {
      pageTitle.textContent = `${data.customer} · 慢箋領藥簡訊智慧發送系統`;
    }
    const licBadge = document.getElementById('licensed-pharmacy-badge');
    if (licBadge) {
      licBadge.style.display = 'inline-block';
      licBadge.textContent = '正式授權';
      licBadge.title = `已授權綁定藥局：${data.customer}`;
    }
    const optFooter = document.getElementById('opt-footer-pharmacy');
    if (optFooter) {
      optFooter.value = `${data.customer}關心您的健康`;
      optFooter.textContent = `${data.customer}關心您的健康`;
    }
    const optSig = document.getElementById('opt-sig-pharmacy');
    if (optSig) {
      optSig.value = `【${data.customer}】`;
      optSig.textContent = `【${data.customer}】`;
    }
    if (typeof appConfig !== 'undefined' && appConfig) {
      appConfig.pharmacy_name = data.customer;
      appConfig.is_licensed = true;
      appConfig.licensed_pharmacy = data.customer;
      if (typeof updateCharCounter === 'function') updateCharCounter();
    }
    const pNameInput = document.getElementById('cfg-pharmacy-name');
    if (pNameInput) {
      pNameInput.value = data.customer;
      pNameInput.title = `已綁定正式授權藥局：${data.customer}`;
    }
  }
}

function updateLicenseBadges(data) {
  const badges = document.querySelectorAll('.global-license-badge, #global-license-badge');
  badges.forEach(badge => {
    if (!badge) return;
    badge.style.display = 'inline-flex';
    badge.style.alignItems = 'center';
    badge.style.gap = '5px';
    badge.style.cursor = 'pointer';

    if (data.is_licensed) {
      badge.style.background = '#DCFCE7';
      badge.style.color = '#166534';
      badge.style.border = '1px solid #86EFAC';
      badge.innerHTML = `<span>🛡️</span> <span>正式授權版</span>`;
      badge.title = `已授權予：${data.customer} (點擊檢視授權)`;
    } else if (data.status === 'TRIAL') {
      badge.style.background = '#FEF3C7';
      badge.style.color = '#92400E';
      badge.style.border = '1px solid #FCD34D';
      badge.innerHTML = `<span>⏳</span> <span>試用版 (剩餘 ${data.days_left} 天)</span>`;
      badge.title = '您目前享有 30 天完整試用期，點擊輸入序號解鎖永久版';
    } else if (data.status === 'EXPIRED') {
      badge.style.background = '#FFE4E6';
      badge.style.color = '#9F1239';
      badge.style.border = '1.5px solid #FDA4AF';
      badge.innerHTML = `<span>⚠️</span> <span>試用已屆滿 (點擊解鎖)</span>`;
      badge.title = '試用期已結束，請輸入序號解鎖';
    } else if (data.status === 'TAMPERED') {
      badge.style.background = '#FEE2E2';
      badge.style.color = '#991B1B';
      badge.style.border = '1.5px solid #F87171';
      badge.innerHTML = `<span>⛔</span> <span>時間異常鎖定</span>`;
      badge.title = '系統時間異常，請校準時間或輸入序號';
    }
  });
}

function enforceLicenseRestrictions(data) {
  if (data.can_write === false) {
    // 試用過期時，若嘗試點擊管制藥品存檔或簡訊送出，彈出授權視窗
    const appendBtn = document.getElementById('regAppendBtn');
    if (appendBtn) {
      appendBtn.setAttribute('data-disabled-by-lic', 'true');
    }
    const sendBtns = document.querySelectorAll('.btn-send-red, #final-confirm-send-btn');
    sendBtns.forEach(b => b.setAttribute('data-disabled-by-lic', 'true'));
  }
}

function updateAboutPageLicense(data) {
  const cardVal = document.getElementById('about-lic-status-val');
  const cardBadge = document.getElementById('about-lic-status-badge');
  const cardHwid = document.getElementById('about-lic-hwid');
  const cardCustomer = document.getElementById('about-lic-customer');
  const cardExpires = document.getElementById('about-lic-expires');

  if (cardVal) {
    cardVal.textContent = data.status_text;
    cardVal.style.color = data.is_licensed ? '#166534' : (data.can_write ? '#92400E' : '#DC2626');
  }
  if (cardBadge) {
    cardBadge.textContent = data.is_licensed ? '正式授權' : (data.can_write ? `試用尚餘 ${data.days_left} 天` : '功能鎖定');
    cardBadge.style.background = data.is_licensed ? '#DCFCE7' : (data.can_write ? '#FEF3C7' : '#FFE4E6');
    cardBadge.style.color = data.is_licensed ? '#166534' : (data.can_write ? '#92400E' : '#9F1239');
  }
  if (cardHwid) cardHwid.textContent = data.hwid;
  if (cardCustomer) cardCustomer.textContent = data.customer || '—';
  if (cardExpires) cardExpires.textContent = data.is_permanent ? '永久正式授權 (無效期限制)' : (data.expires || '30天試用期');
}

// ==========================================
// 2. 授權啟用彈窗 (License Modal)
// ==========================================
function openLicenseModal() {
  const modal = document.getElementById('license-modal');
  if (!modal) return;

  const data = g_licenseStatus || {};
  const hwidInput = document.getElementById('lic-modal-hwid');
  const statusVal = document.getElementById('lic-status-val');
  const statusBadge = document.getElementById('lic-status-badge');
  const keyInput = document.getElementById('lic-modal-key');
  const alertBox = document.getElementById('lic-modal-alert');

  if (hwidInput) hwidInput.value = data.hwid || '讀取中...';
  if (statusVal) statusVal.textContent = data.status_text || '試用版';
  if (statusBadge) {
    statusBadge.textContent = data.is_licensed ? '正式版' : (data.can_write ? '試用中' : '已過期');
    statusBadge.style.background = data.is_licensed ? '#DCFCE7' : (data.can_write ? '#FEF3C7' : '#FFE4E6');
    statusBadge.style.color = data.is_licensed ? '#166534' : (data.can_write ? '#92400E' : '#9F1239');
  }
  if (keyInput) keyInput.value = '';
  if (alertBox) {
    alertBox.style.display = 'none';
    alertBox.innerHTML = '';
  }

  modal.style.display = 'flex';
  setTimeout(() => {
    if (keyInput) keyInput.focus();
  }, 100);
}

function closeLicenseModal() {
  const modal = document.getElementById('license-modal');
  if (modal) modal.style.display = 'none';
}

function copyHWID() {
  const hwidInput = document.getElementById('lic-modal-hwid');
  const textBtn = document.getElementById('copy-hwid-text');
  if (!hwidInput || !hwidInput.value) return;

  navigator.clipboard.writeText(hwidInput.value).then(() => {
    if (textBtn) {
      const orig = textBtn.textContent;
      textBtn.textContent = '已複製！';
      setTimeout(() => { textBtn.textContent = orig; }, 2000);
    }
  }).catch(() => {
    hwidInput.select();
    document.execCommand('copy');
    alert('已複製機器碼至剪貼簿！');
  });
}

async function submitActivation() {
  const keyInput = document.getElementById('lic-modal-key');
  const alertBox = document.getElementById('lic-modal-alert');
  const btn = document.getElementById('lic-activate-btn');
  const key = keyInput ? keyInput.value.trim() : '';

  if (!key) {
    alertBox.style.display = 'block';
    alertBox.style.background = '#FEE2E2';
    alertBox.style.color = '#991B1B';
    alertBox.style.border = '1px solid #F87171';
    alertBox.textContent = '請輸入授權序號！';
    keyInput.focus();
    return;
  }

  btn.disabled = true;
  btn.innerHTML = '<span>⏳</span> 正在驗證非對稱數位簽章...';

  try {
    const res = await fetch('/api/license/activate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ license_key: key })
    });
    const result = await res.json();

    if (result.success) {
      alertBox.style.display = 'block';
      alertBox.style.background = '#DCFCE7';
      alertBox.style.color = '#166534';
      alertBox.style.border = '1px solid #86EFAC';
      alertBox.innerHTML = `<strong>${result.message}</strong>`;

      await initLicenseStatus();
      if (typeof fetchConfig === 'function') {
        try { await fetchConfig(); } catch (e) {}
      }

      setTimeout(() => {
        closeLicenseModal();
      }, 1600);
    } else {
      alertBox.style.display = 'block';
      alertBox.style.background = '#FEE2E2';
      alertBox.style.color = '#991B1B';
      alertBox.style.border = '1px solid #F87171';
      alertBox.innerHTML = `<strong>啟用失敗：</strong>${result.error || '序號無效'}`;
    }
  } catch (err) {
    alertBox.style.display = 'block';
    alertBox.style.background = '#FEE2E2';
    alertBox.style.color = '#991B1B';
    alertBox.style.border = '1px solid #F87171';
    alertBox.textContent = '連線失敗或伺服器異常';
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span>🚀</span> 驗證並解鎖正式版';
  }
}

// ==========================================
// 3. OTA 線上自動更新模組
// ==========================================
async function checkOTAUpdates(isManual = false) {
  const statusBox = document.getElementById('ota-check-result');
  const btn = document.getElementById('ota-check-btn');

  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<span>⏳</span> 正在連線檢查雲端版本...';
  }
  if (statusBox && isManual) {
    statusBox.style.display = 'block';
    statusBox.innerHTML = '<span style="color: #64748B;">正在查詢最新發布資訊...</span>';
  }

  try {
    const res = await fetch('/api/ota/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        manifest_url: 'https://raw.githubusercontent.com/rxcoderapp-bit/rxcoderapp-releases/main/version.json?t=' + Date.now()
      })
    });
    const data = await res.json();

    if (!data.success && !data.has_update) {
      if (statusBox && isManual) {
        statusBox.style.display = 'block';
        statusBox.style.background = '#FEF2F2';
        statusBox.style.border = '1px solid #FCA5A5';
        statusBox.style.color = '#991B1B';
        statusBox.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px; font-weight: 600;">
            <span>⚠️</span>
            <span>檢查更新失敗：${data.error || '無法連線至更新伺服器'}</span>
          </div>
          <span style="font-size: 11.5px; color: #94A3B8; margin-top: 4px; display: block;">檢查時間：${data.checked_at || ''}</span>
        `;
      }
      return;
    }

    if (data.has_update) {
      // 發現新版本
      if (statusBox) {
        statusBox.style.display = 'block';
        statusBox.style.background = '#F0FDF4';
        statusBox.style.border = '1.5px solid #86EFAC';
        statusBox.style.color = '#166534';

        let changelogHtml = '';
        if (data.changelog && data.changelog.length > 0) {
          changelogHtml = '<ul style="margin-left: 20px; margin-top: 6px; font-size: 13px;">' +
            data.changelog.map(item => `<li>${item}</li>`).join('') +
            '</ul>';
        }

        statusBox.innerHTML = `
          <div style="font-weight: 700; font-size: 15px; margin-bottom: 4px; display: flex; align-items: center; gap: 6px;">
            <span>🎉</span> 發現最新版本：${data.latest_version} (目前版本: ${data.current_version})
          </div>
          <div style="font-size: 12px; color: #15803D;">發布日期：${data.release_date || '近期發布'}</div>
          ${changelogHtml}
          <div style="margin-top: 14px;">
            <button type="button" class="btn btn-primary" onclick="triggerOTAUpgrade('${data.download_url}')" style="background: #059669; border-color: #059669; font-weight: 700; padding: 8px 20px; font-size: 14px; display: inline-flex; align-items: center; gap: 8px;">
              <span>🚀</span> 立即下載並自動熱升級
            </button>
          </div>
        `;
      }
    } else {
      // 已是最新版
      if (statusBox && isManual) {
        statusBox.style.display = 'block';
        statusBox.style.background = '#F8FAFC';
        statusBox.style.border = '1px solid #CBD5E1';
        statusBox.style.color = '#334155';
        statusBox.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px; font-weight: 600;">
            <span style="color: #10B981; font-size: 18px;">✅</span>
            <span>目前已是最新版本 (${data.current_version})！無需更新。</span>
          </div>
          <span style="font-size: 11.5px; color: #94A3B8; margin-top: 4px; display: block;">檢查時間：${data.checked_at}</span>
        `;
      }
    }
  } catch (err) {
    if (statusBox && isManual) {
      statusBox.style.display = 'block';
      statusBox.style.background = '#FEF2F2';
      statusBox.style.border = '1px solid #FCA5A5';
      statusBox.style.color = '#991B1B';
      statusBox.innerHTML = `<span>⚠️ 無法連線至更新伺服器或處於離線狀態</span>`;
    }
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<span>🔍</span> 檢查是否有新版本';
    }
  }
}

async function triggerOTAUpgrade(downloadUrl) {
  if (!downloadUrl) {
    alert('無效的下載網址');
    return;
  }

  // 自動對包含中文的 URL 進行標準 URI 轉碼，杜絕 ascii codec 錯誤
  try {
    downloadUrl = encodeURI(decodeURI(downloadUrl));
  } catch (e) {}

  if (!confirm('【RXcoderapp OTA 自動更新確認】\n\n系統將於背景下載最新發布檔，並自動覆蓋更新且重新啟動。\n\n※ 門市現有的管制藥 Excel 簿冊與歷史設定檔將受到 100% 完整保護，絕不覆蓋。\n\n確定立即開始更新？')) {
    return;
  }

  const statusBox = document.getElementById('ota-check-result');
  if (statusBox) {
    statusBox.innerHTML = `
      <div style="padding: 16px 20px; background: #F8FAFC; border: 1.5px solid #0284C7; border-radius: 8px;">
        <div style="font-size: 15px; font-weight: 700; color: #0284C7; margin-bottom: 6px; display: flex; align-items: center; justify-content: space-between;">
          <span id="ota-step-title">⏳ 正在連線下載最新發布檔...</span>
          <span id="ota-percent-badge" style="font-size: 13px; font-weight: 700; color: #0369A1;">0%</span>
        </div>
        <div style="width: 100%; height: 12px; background: #E2E8F0; border-radius: 6px; overflow: hidden; margin-bottom: 8px;">
          <div id="ota-progress-bar" style="width: 0%; height: 100%; background: linear-gradient(90deg, #0284C7, #10B981); transition: width 0.3s ease;"></div>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 12px; color: #64748B;">
          <span id="ota-status-desc">準備下載...</span>
          <span id="ota-size-info">0 MB / 0 MB</span>
        </div>
      </div>
    `;
  }

  try {
    const res = await fetch('/api/ota/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ download_url: downloadUrl })
    });
    const result = await res.json();
    if (!result.success) {
      alert('更新請求啟動失敗: ' + (result.error || '未知錯誤'));
      return;
    }

    // 啟動即時進度輪詢
    const pollTimer = setInterval(async () => {
      try {
        const pRes = await fetch('/api/ota/progress');
        const prog = await pRes.json();

        const titleEl = document.getElementById('ota-step-title');
        const badgeEl = document.getElementById('ota-percent-badge');
        const barEl = document.getElementById('ota-progress-bar');
        const descEl = document.getElementById('ota-status-desc');
        const sizeEl = document.getElementById('ota-size-info');

        if (!titleEl || !barEl) return;

        if (prog.status === 'downloading') {
          const dlMb = (prog.downloaded_bytes / (1024 * 1024)).toFixed(1);
          const totalMb = prog.total_bytes > 0 ? (prog.total_bytes / (1024 * 1024)).toFixed(1) : '?';
          titleEl.innerHTML = `<span>⏳ 正在下載最新版本發布包...</span>`;
          if (badgeEl) badgeEl.textContent = `${prog.percent}%`;
          barEl.style.width = `${prog.percent}%`;
          if (descEl) descEl.textContent = prog.message || '正在串流下載中...';
          if (sizeEl) sizeEl.textContent = `${dlMb} MB / ${totalMb} MB`;
        } else if (prog.status === 'extracting') {
          titleEl.innerHTML = `<span>📦 正在解壓縮新版發布檔案...</span>`;
          if (badgeEl) badgeEl.textContent = `100%`;
          barEl.style.width = `100%`;
          if (descEl) descEl.textContent = '解壓中，即將啟動升級引導...';
        } else if (prog.status === 'ready' || prog.status === 'done') {
          clearInterval(pollTimer);
          titleEl.innerHTML = `<span>🚀 下載完成！正在啟動熱覆蓋並重啟...</span>`;
          titleEl.style.color = '#166534';
          if (badgeEl) badgeEl.textContent = `100%`;
          barEl.style.width = `100%`;
          barEl.style.background = '#10B981';
          if (descEl) descEl.textContent = '軟體即將在 2 秒內安全重啟至最新版本，請稍候！';
        } else if (prog.status === 'error') {
          clearInterval(pollTimer);
          titleEl.innerHTML = `<span>❌ 升級過程發生錯誤</span>`;
          titleEl.style.color = '#DC2626';
          if (descEl) descEl.textContent = prog.error || '未知錯誤';
          alert('OTA 升級失敗：' + (prog.error || '未知錯誤'));
        }
      } catch (err) {
        // 若伺服器已退出（重啟中），停止輪詢
        clearInterval(pollTimer);
        const titleEl = document.getElementById('ota-step-title');
        if (titleEl) {
          titleEl.innerHTML = `<span>🚀 軟體正在自動重新啟動中...</span>`;
          titleEl.style.color = '#166534';
        }
      }
    }, 500);

  } catch (err) {
    alert('更新請求連線失敗: ' + err.message);
  }
}

// 頁面載入時自動初始化授權狀態
document.addEventListener('DOMContentLoaded', () => {
  initLicenseStatus();
});
