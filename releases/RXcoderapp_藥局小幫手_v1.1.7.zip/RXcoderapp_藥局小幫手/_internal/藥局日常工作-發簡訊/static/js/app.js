// Frontend Controller for Pharmacy SMS
let currentRecords = [];
let appConfig = {};
let currentFilter = 'all';
let currentPhoneMode = 'manual';
let userModifiedSchedule = false;

// Excel Smart Mapping & Scheduling State
let currentUploadedFile = null;
let currentLoadedFilename = '';
let availableColumns = [];
let detectedColumns = { name_col: -1, phone_col: -1, date_col: -1 };
let manualColumnOverrides = { name_col: null, phone_col: null, date_col: null };
let fileHasDateColumn = false;
let excelTimingMode = 'scheduled'; // 'instant' or 'scheduled'
let excelSchedSubchoice = 'by_dispense_date'; // 'by_dispense_date' or 'custom_datetime'

document.addEventListener('DOMContentLoaded', () => {
    initApp();
});

async function initApp() {
    await fetchConfig();
    fetchPoints();
    setupEventListeners();
    updateCharCounter();
    updateManualPhonesCount();
    renderTable();
    autoLoadFolderFile(false);

    // Default datetime picker to tomorrow 09:00
    const dtInput = document.getElementById('schedule-datetime-input');
    if (dtInput) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(9, 0, 0, 0);
        const y = tomorrow.getFullYear();
        const m = String(tomorrow.getMonth() + 1).padStart(2, '0');
        const d = String(tomorrow.getDate()).padStart(2, '0');
        const hh = String(tomorrow.getHours()).padStart(2, '0');
        const mm = String(tomorrow.getMinutes()).padStart(2, '0');
        dtInput.value = `${y}-${m}-${d}T${hh}:${mm}`;
    }
}

async function autoLoadFolderFile(isManual = false) {
    const statusHint = document.getElementById('load-status-hint');
    if (statusHint) statusHint.textContent = isManual ? '讀取中...' : '自動載入名冊中...';
    try {
        const formData = new FormData();
        formData.append('template', document.getElementById('template-textarea').value);
        formData.append('merge_same_phone', document.getElementById('merge-phone-checkbox') ? document.getElementById('merge-phone-checkbox').checked : true);
        if (manualColumnOverrides.name_col !== null) formData.append('name_col', manualColumnOverrides.name_col);
        if (manualColumnOverrides.phone_col !== null) formData.append('phone_col', manualColumnOverrides.phone_col);
        if (manualColumnOverrides.date_col !== null) formData.append('date_col', manualColumnOverrides.date_col);

        const res = await fetch('/api/parse', { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success && data.records && data.records.length > 0) {
            if (statusHint) statusHint.textContent = `成功載入 ${data.filename} (${data.records.length} 筆)`;
            const badge = document.getElementById('current-file-badge');
            if (badge) badge.textContent = data.filename;
            const tabCnt = document.getElementById('tab-excel-count');
            if (tabCnt) tabCnt.textContent = `${data.records.length} 筆`;
            handleParsedRecords(data, 'folder');
        } else {
            if (isManual && statusHint) {
                statusHint.textContent = data.error || '載入失敗';
            } else if (statusHint) {
                statusHint.textContent = '';
            }
        }
    } catch (err) {
        if (isManual && statusHint) statusHint.textContent = '讀取異常';
    }
}

async function fetchConfig() {
    try {
        const res = await fetch('/api/config');
        const data = await res.json();
        if (data.success) {
            appConfig = data.config;
            const tArea = document.getElementById('template-textarea');
            const defaultSigName = appConfig.sms_signature || appConfig.pharmacy_name || '緣來藥局';
            if (tArea && (!tArea.value || tArea.value.includes('這裡是緣來藥局~') || tArea.value.includes('這裡是示範藥局~'))) {
                tArea.value = appConfig.default_template || `【${defaultSigName}】{姓名}您好~您的慢性處方箋藥品已準備好了。請於收簡訊後7-10天內攜帶健保卡前來領取，感謝您！`;
            }
            if (document.getElementById('dry-run-toggle')) {
                document.getElementById('dry-run-toggle').checked = !!appConfig.dry_run;
            }
            if (document.getElementById('merge-phone-checkbox')) {
                document.getElementById('merge-phone-checkbox').checked = !!appConfig.merge_same_phone;
            }
            if (document.getElementById('navbar-pharmacy-title') && appConfig.pharmacy_name) {
                document.getElementById('navbar-pharmacy-title').textContent = appConfig.pharmacy_name;
            }
            if (appConfig.pharmacy_name) {
                const pageTitle = document.getElementById('page-title');
                if (pageTitle) {
                    pageTitle.textContent = `${appConfig.pharmacy_name} · 慢箋領藥簡訊智慧發送系統`;
                }
                const optFooter = document.getElementById('opt-footer-pharmacy');
                if (optFooter) {
                    optFooter.value = `${appConfig.pharmacy_name}關心您的健康`;
                    optFooter.textContent = `${appConfig.pharmacy_name}關心您的健康`;
                }
                const optSig = document.getElementById('opt-sig-pharmacy');
                if (optSig) {
                    optSig.value = `【${defaultSigName}】`;
                    optSig.textContent = `【${defaultSigName}】(NCC法定署名 · 已啟用)`;
                }
            }
            const licBadge = document.getElementById('licensed-pharmacy-badge');
            if (licBadge) {
                if (appConfig.is_licensed && appConfig.licensed_pharmacy) {
                    licBadge.style.display = 'inline-block';
                    licBadge.textContent = '正式授權';
                    licBadge.title = `已授權綁定藥局：${appConfig.licensed_pharmacy}`;
                } else {
                    licBadge.style.display = 'none';
                }
            }
            updateDryRunUI();
            renderTemplateSelector();
            updateCharCounter();

            const missingAlert = document.getElementById('api-key-missing-alert');
            if (missingAlert) {
                if (!appConfig.smsgo_api_key || !appConfig.smsgo_username) {
                    missingAlert.style.display = 'flex';
                } else {
                    missingAlert.style.display = 'none';
                }
            }
        }
    } catch (e) {
        console.error('Fetch config error:', e);
    }
}

async function fetchPoints() {
    const pointValEl = document.getElementById('point-val');
    if (!pointValEl) return;
    pointValEl.textContent = '查詢中...';
    try {
        const res = await fetch('/api/points');
        const data = await res.json();
        if (data.success) {
            pointValEl.textContent = `${data.points} 點`;
            pointValEl.style.color = data.points < 100 ? '#dc2626' : '#059669';
        } else {
            pointValEl.textContent = data.error || '未連線';
            pointValEl.style.color = '#dc2626';
        }
    } catch (e) {
        pointValEl.textContent = '查詢失敗';
    }
}

function updateDryRunUI() {
    const isDry = document.getElementById('dry-run-toggle').checked;
    const label = document.getElementById('dry-run-label');
    const alert = document.getElementById('dry-run-alert');
    if (isDry) {
        label.textContent = '🧪 測試模式';
        label.parentElement.parentElement.style.background = '#fef3c7';
        label.parentElement.parentElement.style.borderColor = '#fde68a';
        if (alert) alert.style.display = 'flex';
    } else {
        label.textContent = '🚀 正式模式';
        label.parentElement.parentElement.style.background = '#fee2e2';
        label.parentElement.parentElement.style.borderColor = '#fca5a5';
        if (alert) alert.style.display = 'none';
    }
}

function updateCharCounter() {
    const textarea = document.getElementById('template-textarea');
    if (!textarea) return;
    const text = textarea.value;
    const pName = appConfig.sms_signature || appConfig.pharmacy_name || '緣來藥局';
    let sample = text.replace(/{姓名}/g, '王大明')
                     .replace(/{電話}/g, '0912345678')
                     .replace(/{藥局名稱}/g, pName)
                     .replace(/{調劑日期}/g, '115/09/17');

    // NCC 法定署名防呆模擬：若未含【...】或 [...]，系統自動補齊【藥局名稱】
    const hasSig = /【[^】]+】|\[[^\]]+\]/.test(sample);
    let effectivePreview = sample;
    if (!hasSig && sample.trim()) {
        effectivePreview = `【${pName}】${sample}`;
    }

    const len = effectivePreview.length;
    const points = len <= 70 ? 1 : Math.ceil((len - 70) / 67) + 1;

    const counterEl = document.getElementById('char-count');
    const pointEl = document.getElementById('point-count');
    if (counterEl) counterEl.textContent = len;
    if (pointEl) pointEl.textContent = points;

    // Update Phone Mockup Bubble
    const phoneBubble = document.getElementById('phone-bubble');
    if (phoneBubble) {
        phoneBubble.textContent = effectivePreview || '請輸入簡訊內容...';
    }
}

function parseManualPhoneNumbers() {
    const textarea = document.getElementById('manual-phones-input');
    if (!textarea) return [];
    const raw = textarea.value;
    const tokens = raw.split(/[,;\s\n\r\t]+/);
    const cleaned = [];
    tokens.forEach(t => {
        let digits = t.replace(/\D/g, '');
        if (digits.startsWith('8869') && digits.length === 12) {
            digits = '0' + digits.substring(3);
        } else if (digits.startsWith('9') && digits.length === 9) {
            digits = '0' + digits;
        }
        if (digits.startsWith('09') && digits.length === 10) {
            if (!cleaned.includes(digits)) {
                cleaned.push(digits);
            }
        }
    });
    return cleaned;
}

function updateManualPhonesCount() {
    const phones = parseManualPhoneNumbers();
    const countEl = document.getElementById('manual-phone-count');
    if (countEl) countEl.textContent = phones.length;
}

function switchPhoneMode(mode) {
    currentPhoneMode = mode;
    const tabManual = document.getElementById('tab-mode-manual');
    const tabExcel = document.getElementById('tab-mode-excel');
    const panelManual = document.getElementById('panel-mode-manual');
    const panelExcel = document.getElementById('panel-mode-excel');
    const sendBtn = document.getElementById('main-send-sms-btn');

    if (mode === 'manual') {
        if (tabManual) tabManual.classList.add('active');
        if (tabExcel) tabExcel.classList.remove('active');
        if (panelManual) panelManual.style.display = 'block';
        if (panelExcel) panelExcel.style.display = 'none';
        if (sendBtn) {
            const isSched = document.getElementById('radio-scheduled') && document.getElementById('radio-scheduled').checked;
            sendBtn.innerHTML = isSched ? '<span>⏰ 送出預約簡訊</span>' : '<span>按鍵送出簡訊</span>';
        }
    } else {
        if (tabExcel) tabExcel.classList.add('active');
        if (tabManual) tabManual.classList.remove('active');
        if (panelExcel) panelExcel.style.display = 'block';
        if (panelManual) panelManual.style.display = 'none';
        if (sendBtn) {
            sendBtn.innerHTML = (excelTimingMode === 'instant')
                ? '<span>🚀 立即送出簡訊</span>'
                : '<span>⏰ 送出預約簡訊</span>';
        }
    }
}

function toggleTimingMode() {
    const isScheduled = document.getElementById('radio-scheduled').checked;
    const container = document.getElementById('scheduled-picker-container');
    if (container) {
        container.style.display = isScheduled ? 'flex' : 'none';
    }

    if (currentPhoneMode === 'excel') {
        const targetMode = isScheduled ? 'scheduled' : 'instant';
        if (excelTimingMode !== targetMode) {
            setExcelTimingMode(targetMode, false);
        }
    } else {
        const sendBtn = document.getElementById('main-send-sms-btn');
        if (sendBtn) {
            sendBtn.innerHTML = isScheduled ? '<span>⏰ 送出預約簡訊</span>' : '<span>按鍵送出簡訊</span>';
        }
    }
}

// ==========================================
// 慢箋調劑日自動預約發送 (遇週日自動順延至週一 09:00)
// ==========================================

function parseTaiwanOrWesternDate(rawStr) {
    if (!rawStr) return null;
    const s = String(rawStr).trim();

    // 格式 1: 民國年帶斜線/破折號/點 (例: 115/09/17, 115-09-17, 115.09.17, 115/9/17)
    let m = s.match(/^(\d{2,3})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
    if (m) {
        let y = parseInt(m[1], 10);
        let month = parseInt(m[2], 10);
        let d = parseInt(m[3], 10);
        if (y < 1900) y += 1911; // 民國年轉西元年
        return { year: y, month: month, day: d, raw: s };
    }

    // 格式 2: 西元年帶斜線/破折號/點 (例: 2026/09/17, 2026-09-17)
    m = s.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
    if (m) {
        return {
            year: parseInt(m[1], 10),
            month: parseInt(m[2], 10),
            day: parseInt(m[3], 10),
            raw: s
        };
    }

    // 格式 3: 純 7 碼民國年字串 (例: 1150917)
    m = s.match(/^(\d{3})(\d{2})(\d{2})$/);
    if (m) {
        return {
            year: parseInt(m[1], 10) + 1911,
            month: parseInt(m[2], 10),
            day: parseInt(m[3], 10),
            raw: s
        };
    }

    // 格式 4: 純 8 碼西元年字串 (例: 20260917)
    m = s.match(/^(\d{4})(\d{2})(\d{2})$/);
    if (m) {
        return {
            year: parseInt(m[1], 10),
            month: parseInt(m[2], 10),
            day: parseInt(m[3], 10),
            raw: s
        };
    }

    return null;
}

function calculateScheduleDate(parsedDate) {
    if (!parsedDate) return null;
    // 預設調劑當天 09:00:00 發送
    let d = new Date(parsedDate.year, parsedDate.month - 1, parsedDate.day, 9, 0, 0, 0);
    let originalDayOfWeek = d.getDay(); // 0 代表週日 (Sunday)
    let movedFromSunday = false;

    if (originalDayOfWeek === 0) {
        // 若遇到週日，自動幫我改到隔天週一發送
        d.setDate(d.getDate() + 1);
        movedFromSunday = true;
    }
    d.setHours(9, 0, 0, 0);

    return {
        dateObj: d,
        movedFromSunday: movedFromSunday,
        originalDayOfWeek: originalDayOfWeek
    };
}

function formatToDatetimeLocal(dateObj) {
    const yyyy = dateObj.getFullYear();
    const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
    const dd = String(dateObj.getDate()).padStart(2, '0');
    const hh = String(dateObj.getHours()).padStart(2, '0');
    const min = String(dateObj.getMinutes()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}T${hh}:${min}`;
}

function formatDisplaySchedule(dateObj) {
    const days = ['日', '一', '二', '三', '四', '五', '六'];
    const yyyy = dateObj.getFullYear();
    const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
    const dd = String(dateObj.getDate()).padStart(2, '0');
    const w = days[dateObj.getDay()];
    const hh = String(dateObj.getHours()).padStart(2, '0');
    const min = String(dateObj.getMinutes()).padStart(2, '0');
    return `${yyyy}/${mm}/${dd} (${w}) ${hh}:${min}`;
}

function applyAutoScheduleFromRecords(records, filename = '') {
    if (!records || records.length === 0) return;

    userModifiedSchedule = false;
    let primaryParsedDate = null;
    let sundayCount = 0;

    // 1. 為每筆紀錄解析其調劑日期並計算預約時間
    records.forEach(r => {
        let p = parseTaiwanOrWesternDate(r.date);
        if (p) {
            if (!primaryParsedDate) primaryParsedDate = p;
            let calc = calculateScheduleDate(p);
            r.schedule_datetime = formatToDatetimeLocal(calc.dateObj);
            r.schedule_display = formatDisplaySchedule(calc.dateObj);
            r.schedule_moved_from_sunday = calc.movedFromSunday;
            if (calc.movedFromSunday) sundayCount++;
        }
    });

    // 2. 若紀錄內未附調劑日，嘗試從檔案名稱分析 (例: 1150917.xls, 1140219.xlsx)
    if (!primaryParsedDate && filename) {
        let m = filename.match(/(\d{3,4})[\/\-\._]?(\d{2})[\/\-\._]?(\d{2})/);
        if (m) {
            let y = parseInt(m[1], 10);
            if (y < 1900) y += 1911;
            primaryParsedDate = {
                year: y,
                month: parseInt(m[2], 10),
                day: parseInt(m[3], 10),
                raw: filename
            };
        }
    }

    // 3. 若仍無日期，預設明天 09:00 (若遇週日亦順延至週一)
    if (!primaryParsedDate) {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        primaryParsedDate = {
            year: tomorrow.getFullYear(),
            month: tomorrow.getMonth() + 1,
            day: tomorrow.getDate(),
            raw: '系統預設'
        };
    }

    // 4. 計算批次代表性主預約時間
    const batchCalc = calculateScheduleDate(primaryParsedDate);
    const batchDatetimeLocal = formatToDatetimeLocal(batchCalc.dateObj);
    const batchDisplay = formatDisplaySchedule(batchCalc.dateObj);

    // 補齊未含個別調劑日之紀錄
    records.forEach(r => {
        if (!r.schedule_datetime) {
            r.schedule_datetime = batchDatetimeLocal;
            r.schedule_display = batchDisplay;
            r.schedule_moved_from_sunday = batchCalc.movedFromSunday;
        }
    });

    // 5. 自動切換發送時間選項為「預約發送」並填入預約時間
    const radioScheduled = document.getElementById('radio-scheduled');
    const radioInstant = document.getElementById('radio-instant');
    if (radioScheduled) radioScheduled.checked = true;
    if (radioInstant) radioInstant.checked = false;
    toggleTimingMode();

    const dtInput = document.getElementById('schedule-datetime-input');
    if (dtInput) {
        dtInput.value = batchDatetimeLocal;
    }

    // 6. 更新智慧預約提示橫幅
    const badge = document.getElementById('auto-schedule-badge');
    if (badge) {
        badge.style.display = 'flex';
        if (batchCalc.movedFromSunday || sundayCount > 0) {
            badge.style.background = '#fffbeb';
            badge.style.borderColor = '#fcd34d';
            badge.style.color = '#92400e';
            badge.innerHTML = `
                <span style="font-size: 16px;">⚡</span>
                <div>
                    <strong>已依名冊調劑日期自動啟動「預約發送」：</strong>
                    名冊調劑日為<strong>週日</strong>，已自動為您順延至<strong>隔天週一 (${batchDisplay})</strong> 發送！
                </div>
            `;
        } else {
            badge.style.background = '#ecfdf5';
            badge.style.borderColor = '#a7f3d0';
            badge.style.color = '#065f46';
            badge.innerHTML = `
                <span style="font-size: 16px;">⚡</span>
                <div>
                    <strong>已依名冊調劑日期自動啟動「預約發送」：</strong>
                    依照名冊調劑日期設定於 <strong>${batchDisplay}</strong> 發送 (遇週日自動順延隔天週一)。
                </div>
            `;
        }
    }
}

// ==========================================
// Excel 發送模式 (立即發送 vs 預約發送) 控制引擎
// ==========================================

function setExcelTimingMode(mode, syncStep3 = true) {
    excelTimingMode = mode;
    const btnInstant = document.getElementById('btn-excel-mode-instant');
    const btnSched = document.getElementById('btn-excel-mode-scheduled');
    const schedOptions = document.getElementById('excel-sched-options');
    const radioInstant = document.getElementById('radio-instant');
    const radioSched = document.getElementById('radio-scheduled');
    const sendBtn = document.getElementById('main-send-sms-btn');

    if (mode === 'instant') {
        if (btnInstant) {
            btnInstant.style.background = '#059669';
            btnInstant.style.color = '#ffffff';
            btnInstant.style.boxShadow = '0 1px 3px rgba(0,0,0,0.12)';
        }
        if (btnSched) {
            btnSched.style.background = 'transparent';
            btnSched.style.color = '#475569';
            btnSched.style.boxShadow = 'none';
        }
        if (schedOptions) schedOptions.style.display = 'none';
        if (syncStep3) {
            if (radioInstant) radioInstant.checked = true;
            if (radioSched) radioSched.checked = false;
            toggleTimingMode();
        }
        if (sendBtn && currentPhoneMode === 'excel') {
            sendBtn.innerHTML = '<span>🚀 立即送出簡訊</span>';
        }
    } else {
        if (btnSched) {
            btnSched.style.background = '#0284c7';
            btnSched.style.color = '#ffffff';
            btnSched.style.boxShadow = '0 1px 3px rgba(0,0,0,0.12)';
        }
        if (btnInstant) {
            btnInstant.style.background = 'transparent';
            btnInstant.style.color = '#475569';
            btnInstant.style.boxShadow = 'none';
        }
        if (schedOptions) schedOptions.style.display = 'flex';
        if (syncStep3) {
            if (radioSched) radioSched.checked = true;
            if (radioInstant) radioInstant.checked = false;
            toggleTimingMode();
        }
        if (sendBtn && currentPhoneMode === 'excel') {
            sendBtn.innerHTML = '<span>⏰ 送出預約簡訊</span>';
        }
    }

    updateExcelTimingDescription();
    renderTable();
}

function onExcelSchedSubchoiceChange(choice) {
    excelSchedSubchoice = choice;
    const radioByDispense = document.getElementById('radio-excel-by-dispense');
    const radioCustom = document.getElementById('radio-excel-custom-time');
    if (choice === 'by_dispense_date') {
        if (radioByDispense) radioByDispense.checked = true;
        if (radioCustom) radioCustom.checked = false;
        applyAutoScheduleFromRecords(currentRecords, currentLoadedFilename);
    } else {
        if (radioCustom) radioCustom.checked = true;
        if (radioByDispense) radioByDispense.checked = false;
        const customInput = document.getElementById('excel-toolbar-datetime-input');
        if (customInput && customInput.value) {
            applyCustomDatetimeToRecords(customInput.value);
        }
    }
    updateExcelTimingDescription();
    renderTable();
}

function onExcelToolbarDatetimeChange() {
    const customInput = document.getElementById('excel-toolbar-datetime-input');
    if (!customInput || !customInput.value) return;
    excelSchedSubchoice = 'custom_datetime';
    const radioCustom = document.getElementById('radio-excel-custom-time');
    const radioByDispense = document.getElementById('radio-excel-by-dispense');
    if (radioCustom) radioCustom.checked = true;
    if (radioByDispense) radioByDispense.checked = false;

    // 同步到步驟 ③ 的全域預約時間選取器
    const step3Dt = document.getElementById('schedule-datetime-input');
    if (step3Dt) step3Dt.value = customInput.value;

    applyCustomDatetimeToRecords(customInput.value);
    updateExcelTimingDescription();
    renderTable();
}

function applyCustomDatetimeToRecords(dtValue) {
    if (!dtValue) return;
    const dateObj = new Date(dtValue);
    const displayStr = formatDisplaySchedule(dateObj);
    currentRecords.forEach(r => {
        r.schedule_datetime = dtValue;
        r.schedule_display = displayStr;
        r.schedule_moved_from_sunday = false;
    });
}

function updateExcelTimingDescription() {
    const descEl = document.getElementById('excel-timing-description');
    if (!descEl) return;

    if (excelTimingMode === 'instant') {
        descEl.style.color = '#059669';
        descEl.innerHTML = `⚡ <strong>目前為【立即發送模式】</strong>：勾選欲發送的病患名單後點擊送出，系統將<strong>即刻</strong>由簡訊閘道為所有人推播通知。`;
    } else {
        descEl.style.color = '#0284c7';
        if (excelSchedSubchoice === 'by_dispense_date' && fileHasDateColumn) {
            const hasMovedSunday = currentRecords.some(r => r.schedule_moved_from_sunday);
            if (hasMovedSunday) {
                descEl.innerHTML = `⏰ <strong>目前為【預約發送模式】</strong>：依名冊各筆調劑日期預約於<strong>當日早上 09:00</strong> 發送；<span style="color:#b45309; background:#fef3c7; border:1px solid #fde68a; padding:1px 6px; border-radius:4px; font-weight:700;">名冊內遇週日名單已自動順延至週一 09:00 發送</span>。`;
            } else {
                descEl.innerHTML = `⏰ <strong>目前為【預約發送模式】</strong>：已依名冊調劑日期自動預約於<strong>當日早上 09:00</strong> 發送。`;
            }
        } else {
            const customInput = document.getElementById('excel-toolbar-datetime-input');
            const val = customInput ? customInput.value : '';
            descEl.innerHTML = `⏰ <strong>目前為【預約發送模式】</strong>：名冊中所有勾選之病患將統一預約於 <strong>${val ? val.replace('T', ' ') : '指定時間'}</strong> 發送。`;
        }
    }
}

function setupExcelTimingBar(filename) {
    const timingBar = document.getElementById('excel-timing-mode-bar');
    if (!timingBar) return;
    timingBar.style.display = 'block';

    const byDispenseWrap = document.getElementById('excel-sched-by-dispense-wrap');
    const radioByDispense = document.getElementById('radio-excel-by-dispense');
    const radioCustom = document.getElementById('radio-excel-custom-time');
    const customInput = document.getElementById('excel-toolbar-datetime-input');

    // 計算預設預約時間 (明日 09:00，若遇週日自動順延週一)
    const defDate = new Date();
    defDate.setDate(defDate.getDate() + 1);
    defDate.setHours(9, 0, 0, 0);
    if (defDate.getDay() === 0) {
        defDate.setDate(defDate.getDate() + 1);
    }
    const defLocal = formatToDatetimeLocal(defDate);
    if (customInput) customInput.value = defLocal;
    const step3Dt = document.getElementById('schedule-datetime-input');
    if (step3Dt) step3Dt.value = defLocal;

    if (fileHasDateColumn) {
        if (byDispenseWrap) byDispenseWrap.style.display = 'flex';
        excelSchedSubchoice = 'by_dispense_date';
        if (radioByDispense) radioByDispense.checked = true;
        if (radioCustom) radioCustom.checked = false;
        applyAutoScheduleFromRecords(currentRecords, filename);
    } else {
        if (byDispenseWrap) byDispenseWrap.style.display = 'none';
        excelSchedSubchoice = 'custom_datetime';
        if (radioCustom) radioCustom.checked = true;
        if (radioByDispense) radioByDispense.checked = false;
        applyCustomDatetimeToRecords(defLocal);
    }

    setExcelTimingMode(excelTimingMode, false);
}

// ==========================================
// 欄位智慧辨識與手動對應控制
// ==========================================

function renderColumnMappingBar() {
    const mapperBar = document.getElementById('excel-column-mapper-bar');
    if (!mapperBar || availableColumns.length === 0) return;
    mapperBar.style.display = 'block';

    const selName = document.getElementById('col-select-name');
    const selPhone = document.getElementById('col-select-phone');
    const selDate = document.getElementById('col-select-date');
    if (!selName || !selPhone || !selDate) return;

    const curNameIdx = manualColumnOverrides.name_col !== null ? manualColumnOverrides.name_col : detectedColumns.name_col;
    const curPhoneIdx = manualColumnOverrides.phone_col !== null ? manualColumnOverrides.phone_col : detectedColumns.phone_col;
    const curDateIdx = manualColumnOverrides.date_col !== null ? manualColumnOverrides.date_col : detectedColumns.date_col;

    selName.innerHTML = availableColumns.map(c => `<option value="${c.index}" ${c.index === curNameIdx ? 'selected' : ''}>${c.name}</option>`).join('');
    selPhone.innerHTML = availableColumns.map(c => `<option value="${c.index}" ${c.index === curPhoneIdx ? 'selected' : ''}>${c.name}</option>`).join('');
    selDate.innerHTML = `<option value="-1" ${curDateIdx === -1 ? 'selected' : ''}>（無日期 / 自訂預約）</option>` +
        availableColumns.map(c => `<option value="${c.index}" ${c.index === curDateIdx ? 'selected' : ''}>${c.name}</option>`).join('');

    const badge = document.getElementById('excel-column-auto-badge');
    if (badge) {
        const phoneColName = (availableColumns.find(c => c.index === curPhoneIdx) || {}).name || '電話/手機';
        const nameColName = (availableColumns.find(c => c.index === curNameIdx) || {}).name || '姓名';
        badge.textContent = `已自動對應：[${nameColName}] ➔ 姓名、[${phoneColName}] ➔ 手機門號`;
        badge.style.background = '#ecfdf5';
        badge.style.color = '#065f46';
        badge.style.borderColor = '#a7f3d0';
    }
}

async function onColumnDropdownChange() {
    const selName = document.getElementById('col-select-name');
    const selPhone = document.getElementById('col-select-phone');
    const selDate = document.getElementById('col-select-date');
    manualColumnOverrides.name_col = parseInt(selName.value, 10);
    manualColumnOverrides.phone_col = parseInt(selPhone.value, 10);
    manualColumnOverrides.date_col = parseInt(selDate.value, 10);

    const badge = document.getElementById('excel-column-auto-badge');
    if (badge) {
        badge.textContent = '手動自訂欄位已生效';
        badge.style.background = '#e0f2fe';
        badge.style.color = '#0369a1';
        badge.style.borderColor = '#bae6fd';
    }

    await reloadCurrentExcelData();
}

async function resetDefaultColumns() {
    manualColumnOverrides = { name_col: null, phone_col: null, date_col: null };
    await reloadCurrentExcelData();
}

async function reloadCurrentExcelData() {
    const formData = new FormData();
    if (currentUploadedFile && typeof currentUploadedFile !== 'string') {
        formData.append('file', currentUploadedFile);
    }
    formData.append('template', document.getElementById('template-textarea').value);
    formData.append('merge_same_phone', document.getElementById('merge-phone-checkbox') ? document.getElementById('merge-phone-checkbox').checked : true);
    if (manualColumnOverrides.name_col !== null) formData.append('name_col', manualColumnOverrides.name_col);
    if (manualColumnOverrides.phone_col !== null) formData.append('phone_col', manualColumnOverrides.phone_col);
    if (manualColumnOverrides.date_col !== null) formData.append('date_col', manualColumnOverrides.date_col);

    try {
        const res = await fetch('/api/parse', { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success) {
            handleParsedRecords(data, currentUploadedFile);
        } else {
            alert('重新解析失敗: ' + (data.error || ''));
        }
    } catch (e) {
        console.error('Reload excel error:', e);
    }
}

function fillSelfTestPhone() {
    const input = document.getElementById('manual-phones-input');
    if (!input) return;
    const userPhone = prompt('請輸入您的測試手機號碼 (09開頭10碼)：', '0912345678');
    if (userPhone && userPhone.trim()) {
        const cleaned = userPhone.trim();
        if (input.value.trim()) {
            input.value = input.value.trim() + ',\n' + cleaned;
        } else {
            input.value = cleaned;
        }
        updateManualPhonesCount();
    }
}

function insertTag(tag) {
    const textarea = document.getElementById('template-textarea');
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    textarea.value = text.substring(0, start) + tag + text.substring(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + tag.length;
    updateCharCounter();
}

function setupEventListeners() {
    // Dry run toggle
    const dryRunToggle = document.getElementById('dry-run-toggle');
    if (dryRunToggle) {
        dryRunToggle.addEventListener('change', async (e) => {
            updateDryRunUI();
            await saveConfigChange({ dry_run: e.target.checked });
        });
    }

    // Refresh point button
    const refreshBtn = document.getElementById('refresh-point-btn');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', () => fetchPoints());
    }

    // Quick fill self test
    const btnQuickSelf = document.getElementById('btn-quick-fill-self');
    if (btnQuickSelf) {
        btnQuickSelf.addEventListener('click', fillSelfTestPhone);
    }

    // Quick canned button
    const btnCanned = document.getElementById('btn-show-canned');
    if (btnCanned) {
        btnCanned.addEventListener('click', () => {
            const sel = document.getElementById('saved-template-select');
            if (sel) {
                sel.focus();
                sel.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });
    }

    // Quick headers, bodies, footers
    const qHeader = document.getElementById('quick-header-select');
    if (qHeader) {
        qHeader.addEventListener('change', (e) => {
            if (!e.target.value) return;
            const tArea = document.getElementById('template-textarea');
            tArea.value = e.target.value + tArea.value;
            e.target.value = '';
            updateCharCounter();
        });
    }

    const qBody = document.getElementById('quick-body-select');
    if (qBody) {
        qBody.addEventListener('change', (e) => {
            if (!e.target.value) return;
            const tArea = document.getElementById('template-textarea');
            if (tArea.value.trim()) {
                tArea.value = tArea.value.trim() + ' ' + e.target.value;
            } else {
                tArea.value = e.target.value;
            }
            e.target.value = '';
            updateCharCounter();
        });
    }

    const qFooter = document.getElementById('quick-footer-select');
    if (qFooter) {
        qFooter.addEventListener('change', (e) => {
            if (!e.target.value) return;
            const tArea = document.getElementById('template-textarea');
            tArea.value = tArea.value.trim() + ' ' + e.target.value;
            e.target.value = '';
            updateCharCounter();
        });
    }

    // Signature select
    const sigSelect = document.getElementById('signature-select');
    if (sigSelect) {
        sigSelect.addEventListener('change', (e) => {
            if (!e.target.value) return;
            const tArea = document.getElementById('template-textarea');
            if (!tArea.value.includes(e.target.value)) {
                tArea.value = tArea.value.trim() + ' ' + e.target.value;
                updateCharCounter();
            }
        });
    }

    // Manual phones textarea
    const manualPhonesInput = document.getElementById('manual-phones-input');
    if (manualPhonesInput) {
        manualPhonesInput.addEventListener('input', updateManualPhonesCount);
    }

    // Schedule datetime input change
    const dtInput = document.getElementById('schedule-datetime-input');
    if (dtInput) {
        dtInput.addEventListener('input', () => {
            userModifiedSchedule = true;
            const badge = document.getElementById('auto-schedule-badge');
            if (badge) {
                badge.style.display = 'flex';
                badge.style.background = '#f0f9ff';
                badge.style.borderColor = '#bae6fd';
                badge.style.color = '#0369a1';
                badge.innerHTML = `<span>✏️</span> <div><strong>已手動指定預約時間：</strong>${dtInput.value.replace('T', ' ')}</div>`;
            }
        });
    }

    // Template input change
    const textarea = document.getElementById('template-textarea');
    if (textarea) {
        textarea.addEventListener('input', updateCharCounter);
    }

    // Template Dropdown Selection
    const templateSelect = document.getElementById('saved-template-select');
    if (templateSelect) {
        templateSelect.addEventListener('change', (e) => {
            const selectedName = e.target.value;
            if (selectedName === '__manage__') {
                e.target.value = '';
                openTemplateModal();
                return;
            }
            if (!selectedName) return;
            const tpls = appConfig.saved_templates || [];
            const found = tpls.find(t => t.name === selectedName);
            if (found) {
                document.getElementById('template-textarea').value = found.content;
                updateCharCounter();
                if (currentRecords.length > 0) {
                    recalculateTemplate();
                }
            }
        });
    }

    // Modal template content input listener
    const tplFormContent = document.getElementById('tpl-form-content');
    if (tplFormContent) {
        tplFormContent.addEventListener('input', updateTplCharCounter);
    }

    // Load folder file button
    const loadFolderBtn = document.getElementById('load-folder-btn');
    if (loadFolderBtn) {
        loadFolderBtn.addEventListener('click', async () => {
            await autoLoadFolderFile(true);
        });
    }

    // File input & Drag drop
    const fileInput = document.getElementById('file-input');
    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                uploadFile(e.target.files[0]);
            }
        });
    }

    // Merge phone checkbox
    const mergeCheckbox = document.getElementById('merge-phone-checkbox');
    if (mergeCheckbox) {
        mergeCheckbox.addEventListener('change', async (e) => {
            await saveConfigChange({ merge_same_phone: e.target.checked });
            const lBtn = document.getElementById('load-folder-btn');
            if (lBtn) lBtn.click();
        });
    }

    // Master checkbox
    const masterCheckbox = document.getElementById('master-checkbox');
    if (masterCheckbox) {
        masterCheckbox.addEventListener('change', (e) => {
            const checked = e.target.checked;
            currentRecords.forEach(r => {
                if (r.is_valid_mobile) r.selected = checked;
            });
            renderTable();
            updateSummaryStats();
        });
    }

    // Point badge click to check points or open settings
    const pointBadge = document.getElementById('point-badge');
    if (pointBadge) {
        pointBadge.style.cursor = 'pointer';
        pointBadge.addEventListener('click', (e) => {
            if (e.target.id === 'refresh-point-btn') return;
            if (!appConfig.smsgo_api_key || !appConfig.smsgo_username) {
                openSettingsModal();
            } else {
                fetchPoints();
            }
        });
    }

    // Settings Modal
    document.getElementById('open-settings-btn').addEventListener('click', openSettingsModal);

    // Test Connection Button in Settings Modal
    const testBtn = document.getElementById('test-connection-btn');
    if (testBtn) {
        testBtn.addEventListener('click', async () => {
            const username = document.getElementById('cfg-smsgo-username').value.trim();
            const key = document.getElementById('cfg-smsgo-key').value.trim();
            const resBox = document.getElementById('test-conn-result');
            if (!username || !key) {
                resBox.style.display = 'block';
                resBox.style.background = '#fef2f2';
                resBox.style.color = '#991b1b';
                resBox.style.border = '1px solid #f87171';
                resBox.innerHTML = '⚠️ 請先輸入 SMSGO 會員帳號與 API Key / 密碼再進行測試！';
                return;
            }

            testBtn.disabled = true;
            testBtn.innerHTML = '⏳ 正在連線 SMSGO 官方伺服器...';
            resBox.style.display = 'block';
            resBox.style.background = '#f0f9ff';
            resBox.style.color = '#0369a1';
            resBox.style.border = '1px solid #7dd3fc';
            resBox.innerHTML = '📡 正在向 SMSGO 閘道驗證帳密與查詢點數 (query_point.asp)...';

            try {
                const res = await fetch('/api/points', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ smsgo_username: username, smsgo_api_key: key })
                });
                const data = await res.json();
                if (data.success) {
                    resBox.style.background = '#ecfdf5';
                    resBox.style.color = '#065f46';
                    resBox.style.border = '1px solid #6ee7b7';
                    resBox.innerHTML = `✅ <strong>連線成功！官方驗證通過</strong><br>目前帳戶剩餘可用點數：<strong style="font-size:15px; color:#059669;">${data.points} 點</strong>`;
                } else {
                    resBox.style.background = '#fef2f2';
                    resBox.style.color = '#991b1b';
                    resBox.style.border = '1px solid #f87171';
                    resBox.innerHTML = `❌ <strong>連線失敗或驗證未通過</strong><br>伺服器回傳：${data.error || '連線逾時'}<br><span style="font-size:12px; font-weight:normal; color:#7f1d1d;">提示：若初次使用請洽 SMSGO 官方客服確認開通 API，或檢查帳密與白名單 IP。</span>`;
                }
            } catch (err) {
                resBox.style.background = '#fef2f2';
                resBox.style.color = '#991b1b';
                resBox.style.border = '1px solid #f87171';
                resBox.innerHTML = `❌ 連線發生異常：${err.message}`;
            } finally {
                testBtn.disabled = false;
                testBtn.innerHTML = '<span>🔍</span> 測試連線與查點數';
            }
        });
    }

    document.getElementById('save-settings-btn').addEventListener('click', async () => {
        const newCfg = {
            pharmacy_name: document.getElementById('cfg-pharmacy-name').value.trim(),
            sms_signature: (document.getElementById('cfg-sms-sig') ? document.getElementById('cfg-sms-sig').value.trim() : ''),
            smsgo_username: document.getElementById('cfg-smsgo-username').value.trim(),
            smsgo_api_key: document.getElementById('cfg-smsgo-key').value.trim()
        };
        await saveConfigChange(newCfg);
        closeModal('settings-modal');
        const missingAlert = document.getElementById('api-key-missing-alert');
        if (missingAlert) {
            missingAlert.style.display = (newCfg.smsgo_api_key && newCfg.smsgo_username) ? 'none' : 'flex';
        }
        if (document.getElementById('navbar-pharmacy-title') && newCfg.pharmacy_name) {
            document.getElementById('navbar-pharmacy-title').textContent = newCfg.pharmacy_name;
        }
        fetchPoints();
        updateCharCounter();
        alert('✅ 簡訊系統設定已儲存！');
    });

    // History Modal
    document.getElementById('open-history-btn').addEventListener('click', async () => {
        openModal('history-modal');
        loadHistory();
    });

    // Final Confirm send button
    document.getElementById('final-confirm-send-btn').addEventListener('click', () => {
        closeModal('confirm-modal');
        executeSending();
    });
}

// ----------------------------------------------------
// Core Sending Execution
// ----------------------------------------------------
function triggerMainSend() {
    const content = document.getElementById('template-textarea').value.trim();
    if (!content) {
        alert('請先在「步驟 ①」輸入簡訊內容！');
        document.getElementById('template-textarea').focus();
        return;
    }

    const isScheduled = document.getElementById('radio-scheduled').checked;
    let dsttime = null;
    if (isScheduled) {
        const dtInput = document.getElementById('schedule-datetime-input');
        if (!dtInput || !dtInput.value) {
            alert('您選擇了「預約發送」，請選取預約發送日期與時間！');
            if (dtInput) dtInput.focus();
            return;
        }
        dsttime = dtInput.value;
    }

    const isDry = document.getElementById('dry-run-toggle').checked;

    if (currentPhoneMode === 'manual') {
        const phones = parseManualPhoneNumbers();
        if (phones.length === 0) {
            alert('請在「步驟 ②」手動輸入框中填入至少一個有效的手機門號 (09開頭10碼)！');
            document.getElementById('manual-phones-input').focus();
            return;
        }
        const sigName = appConfig.sms_signature || appConfig.pharmacy_name || '緣來藥局';
        let effectiveContent = content;
        if (!/【[^】]+】|\[[^\]]+\]/.test(effectiveContent)) {
            effectiveContent = `【${sigName}】${effectiveContent}`;
        }
        const ptsPerMsg = effectiveContent.length <= 70 ? 1 : Math.ceil((effectiveContent.length - 70) / 67) + 1;
        const totalPts = phones.length * ptsPerMsg;

        document.getElementById('confirm-modal-desc').innerHTML = `即將發送簡訊給 <strong>${phones.length}</strong> 組門號<br><span style="display:inline-block; font-size:12px; color:#047857; margin-top:4px; background:#ecfdf5; padding:2px 8px; border-radius:4px; border:1px solid #a7f3d0;">🛡️ 已啟動 NCC 法定署名自動防呆保護：【${sigName}】</span>`;
        document.getElementById('confirm-mode-text').textContent = isDry ? '🧪 測試模式 (不扣款)' : '🚀 正式模式 (真實扣點)';
        document.getElementById('confirm-mode-text').style.color = isDry ? '#d97706' : '#dc2626';
        document.getElementById('confirm-points-text').textContent = `${totalPts} 點`;

        const schedBox = document.getElementById('confirm-schedule-text');
        if (schedBox) {
            if (isScheduled) {
                schedBox.style.display = 'block';
                schedBox.textContent = `⏰ 預約發送時間：${dsttime.replace('T', ' ')}`;
            } else {
                schedBox.style.display = 'none';
            }
        }

        openModal('confirm-modal');
    } else {
        // Excel mode
        const selected = currentRecords.filter(r => r.selected && r.is_valid_mobile);
        if (selected.length === 0) {
            alert('請在「步驟 ②」的調劑名冊中勾選欲發送的病患名單！');
            return;
        }
        const totalPts = selected.reduce((sum, r) => sum + r.point_estimate, 0);

        document.getElementById('confirm-modal-desc').innerHTML = `即將向調劑名冊中的 <strong>${selected.length}</strong> 位病患發送領藥簡訊。`;
        document.getElementById('confirm-mode-text').textContent = isDry ? '🧪 測試模式 (不扣款)' : '🚀 正式模式 (真實扣點)';
        document.getElementById('confirm-mode-text').style.color = isDry ? '#d97706' : '#dc2626';
        document.getElementById('confirm-points-text').textContent = `${totalPts} 點`;

        const schedBox = document.getElementById('confirm-schedule-text');
        if (schedBox) {
            if (excelTimingMode === 'instant') {
                schedBox.style.display = 'block';
                schedBox.style.color = '#059669';
                schedBox.innerHTML = `⚡ 發送時程：<strong>立即發送</strong> <span style="display:block; font-size:12px; color:#059669; margin-top:2px;">(送出後即刻由簡訊閘道推播)</span>`;
            } else {
                schedBox.style.display = 'block';
                schedBox.style.color = '#0284c7';
                if (excelSchedSubchoice === 'by_dispense_date' && fileHasDateColumn) {
                    const hasSunday = selected.some(r => r.schedule_moved_from_sunday);
                    if (hasSunday && !userModifiedSchedule) {
                        schedBox.innerHTML = `⏰ 預約發送時間：<strong>依名冊調劑日 09:00 發送</strong> <span style="display:block; font-size:12px; color:#d97706; margin-top:2px;">(名冊內含週日之病患已自動順延至週一發送)</span>`;
                    } else {
                        schedBox.innerHTML = `⏰ 預約發送時間：<strong>依名冊調劑日 09:00 發送</strong>`;
                    }
                } else {
                    const customInput = document.getElementById('excel-toolbar-datetime-input') || document.getElementById('schedule-datetime-input');
                    const targetTime = customInput ? customInput.value : '';
                    schedBox.innerHTML = `⏰ 預約發送時間：<strong>${targetTime ? targetTime.replace('T', ' ') : '指定時間'}</strong>`;
                }
            }
        }

        openModal('confirm-modal');
    }
}

async function executeSending() {
    const isScheduled = (currentPhoneMode === 'manual')
        ? (document.getElementById('radio-scheduled') && document.getElementById('radio-scheduled').checked)
        : (excelTimingMode === 'scheduled');

    const dtInput = document.getElementById('schedule-datetime-input');
    const customToolbarInput = document.getElementById('excel-toolbar-datetime-input');
    const defaultDstTime = isScheduled ? ((customToolbarInput && customToolbarInput.value) || (dtInput ? dtInput.value : null)) : null;

    const isDry = document.getElementById('dry-run-toggle').checked;
    const content = document.getElementById('template-textarea').value.trim();
    const sendBtn = document.getElementById('main-send-sms-btn');

    sendBtn.disabled = true;
    sendBtn.innerHTML = '<span>⏳ 簡訊發送傳送中...</span>';

    if (currentPhoneMode === 'manual') {
        const phones = parseManualPhoneNumbers();
        try {
            const res = await fetch('/api/send_custom', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    phone_numbers: phones,
                    content: content,
                    dsttime: defaultDstTime,
                    dry_run: isDry
                })
            });
            const data = await res.json();
            if (data.success) {
                alert(`🎉 簡訊發送完成！\n總通數：${data.total} 通\n成功：${data.sent_count} 通\n失敗：${data.failed_count} 通\n扣除點數：${data.points_used} 點\n模式：${isDry ? '測試模式' : '正式發送'}${defaultDstTime ? '\n預約時間：' + defaultDstTime.replace('T', ' ') : ''}`);
            } else {
                alert('發送失敗：' + (data.error || '未知錯誤'));
            }
        } catch (e) {
            alert('連線異常，請確認網路連線或稍後再試：' + e.message);
        } finally {
            sendBtn.disabled = false;
            sendBtn.innerHTML = isScheduled ? '<span>⏰ 送出預約簡訊</span>' : '<span>按鍵送出簡訊</span>';
            fetchPoints();
        }
    } else {
        // Excel batch sending
        const selected = currentRecords.filter(r => r.selected && r.is_valid_mobile);
        let successCount = 0;
        let failCount = 0;
        let lastUsedDstTime = null;

        for (let i = 0; i < selected.length; i++) {
            const item = selected[i];
            item.send_status = 'sending';
            renderTable();

            let recordDstTime = null;
            if (isScheduled) {
                if (excelSchedSubchoice === 'by_dispense_date' && fileHasDateColumn && item.schedule_datetime) {
                    recordDstTime = item.schedule_datetime;
                } else {
                    recordDstTime = (customToolbarInput && customToolbarInput.value) ? customToolbarInput.value : item.schedule_datetime;
                }
            } else {
                recordDstTime = null; // ⚡ 立即發送
            }
            lastUsedDstTime = recordDstTime;

            try {
                const res = await fetch('/api/send_single', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        record: item,
                        dsttime: recordDstTime,
                        is_scheduled: isScheduled,
                        dry_run: isDry
                    })
                });
                const data = await res.json();
                if (data.success) {
                    item.send_status = 'success';
                    item.send_result = data.statusstr || '成功';
                    successCount++;
                } else {
                    item.send_status = 'failed';
                    item.send_result = data.error || '失敗';
                    failCount++;
                }
            } catch (err) {
                item.send_status = 'failed';
                item.send_result = '網路超時';
                failCount++;
            }
        }

        renderTable();
        sendBtn.disabled = false;
        sendBtn.innerHTML = (excelTimingMode === 'instant')
            ? '<span>🚀 立即送出簡訊</span>'
            : '<span>⏰ 送出預約簡訊</span>';
        fetchPoints();

        const timingMsg = isScheduled ? `\n預約發送：${lastUsedDstTime ? lastUsedDstTime.replace('T', ' ') : '已排程發送'}` : '\n發送時程：⚡ 立即發送完成';
        alert(`🎉 調劑名冊批次發送完成！\n成功：${successCount} 筆\n失敗：${failCount} 筆\n模式：${isDry ? '測試模式' : '正式發送'}${timingMsg}`);
    }
}

function openSettingsModal() {
    const pNameInput = document.getElementById('cfg-pharmacy-name');
    if (pNameInput) {
        pNameInput.value = appConfig.pharmacy_name || '緣來藥局';
        if (appConfig.is_licensed && appConfig.licensed_pharmacy) {
            pNameInput.value = appConfig.licensed_pharmacy;
            pNameInput.title = `已綁定正式授權藥局：${appConfig.licensed_pharmacy}`;
        }
    }
    const sigInput = document.getElementById('cfg-sms-sig');
    if (sigInput) {
        sigInput.value = appConfig.sms_signature || appConfig.pharmacy_name || '緣來藥局';
    }
    document.getElementById('cfg-smsgo-username').value = appConfig.smsgo_username || '';
    document.getElementById('cfg-smsgo-key').value = appConfig.smsgo_api_key || '';
    const resBox = document.getElementById('test-conn-result');
    if (resBox) {
        resBox.style.display = 'none';
        resBox.innerHTML = '';
    }
    openModal('settings-modal');
    setTimeout(() => {
        const keyInput = document.getElementById('cfg-smsgo-key');
        if (keyInput) keyInput.focus();
    }, 150);
}

function renderTemplateSelector(selectedName = '') {
    const select = document.getElementById('saved-template-select');
    if (!select) return;

    const templates = appConfig.saved_templates || [];
    select.innerHTML = `<option value="">------熱門罐頭簡訊 (${templates.length} 組)------</option>`;

    templates.forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.name;
        opt.textContent = t.name;
        if (selectedName && t.name === selectedName) {
            opt.selected = true;
        }
        select.appendChild(opt);
    });

    const optManage = document.createElement('option');
    optManage.value = '__manage__';
    optManage.textContent = '➕ 自訂新增 / 管理罐頭簡訊...';
    optManage.style.fontWeight = 'bold';
    optManage.style.color = '#059669';
    select.appendChild(optManage);
}

async function saveConfigChange(changes) {
    try {
        const res = await fetch('/api/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(changes)
        });
        const data = await res.json();
        if (data.success) {
            appConfig = data.config;
        }
    } catch (e) {
        console.error('Save config error:', e);
    }
}

async function uploadFile(file) {
    currentUploadedFile = file;
    currentLoadedFilename = file.name;
    manualColumnOverrides = { name_col: null, phone_col: null, date_col: null };

    const statusHint = document.getElementById('load-status-hint');
    if (statusHint) statusHint.textContent = `上傳解析中: ${file.name}...`;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('template', document.getElementById('template-textarea').value);
    formData.append('merge_same_phone', document.getElementById('merge-phone-checkbox') ? document.getElementById('merge-phone-checkbox').checked : true);

    try {
        const res = await fetch('/api/parse', { method: 'POST', body: formData });
        const data = await res.json();
        if (data.success) {
            if (statusHint) statusHint.textContent = `成功載入 ${data.filename} (${data.records.length} 筆)`;
            const badge = document.getElementById('current-file-badge');
            if (badge) badge.textContent = data.filename;
            const tabCnt = document.getElementById('tab-excel-count');
            if (tabCnt) tabCnt.textContent = `${data.records.length} 筆`;
            handleParsedRecords(data, file);
        } else {
            if (statusHint) statusHint.textContent = data.error || '解析失敗';
            alert('解析失敗: ' + (data.error || '未知原因'));
        }
    } catch (e) {
        if (statusHint) statusHint.textContent = '上傳失敗';
        alert('上傳發生錯誤');
    }
}

function handleParsedRecords(data, fileSource = null) {
    currentRecords = data.records;
    currentLoadedFilename = data.filename || '';
    availableColumns = data.available_columns || [];
    detectedColumns = data.detected_columns || { name_col: -1, phone_col: -1, date_col: -1 };
    fileHasDateColumn = !!data.has_date_column;
    if (fileSource) currentUploadedFile = fileSource;

    switchPhoneMode('excel');
    renderColumnMappingBar();
    setupExcelTimingBar(data.filename);
    renderTable();
    updateSummaryStats();
}

async function recalculateTemplate() {
    if (currentRecords.length === 0) return;
    const template = document.getElementById('template-textarea').value;
    try {
        const res = await fetch('/api/recalculate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                template: template,
                pharmacy_name: appConfig.pharmacy_name || '示範藥局',
                records: currentRecords
            })
        });
        const data = await res.json();
        if (data.success) {
            currentRecords = data.records;
            renderTable();
            updateSummaryStats();
            saveConfigChange({ default_template: template });
        }
    } catch (e) {
        console.error('Recalculate error:', e);
    }
}

function updateSummaryStats() {
    const total = currentRecords.length;
    const valid = currentRecords.filter(r => r.is_valid_mobile).length;
    const invalid = total - valid;
    const selectedList = currentRecords.filter(r => r.selected && r.is_valid_mobile);
    const selectedCount = selectedList.length;
    const selectedPoints = selectedList.reduce((sum, r) => sum + r.point_estimate, 0);

    const sTot = document.getElementById('stat-total');
    if (sTot) sTot.textContent = total;
    const sVal = document.getElementById('stat-valid');
    if (sVal) sVal.textContent = valid;
    const sInv = document.getElementById('stat-invalid');
    if (sInv) sInv.textContent = invalid;
    const sSel = document.getElementById('stat-selected');
    if (sSel) sSel.textContent = selectedCount;
    const sPts = document.getElementById('stat-points');
    if (sPts) sPts.textContent = `${selectedPoints} 點`;
}

function renderTable() {
    const tbody = document.getElementById('records-tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    const thSchedule = document.getElementById('th-schedule-header');
    if (thSchedule) {
        thSchedule.textContent = (excelTimingMode === 'instant') ? '發送時程 (⚡ 立即發送)' : '發送時程 / 調劑日';
    }

    if (!currentRecords || currentRecords.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="10" style="text-align: center; padding: 36px 20px; color: #64748b;">
                    <div style="font-size: 28px; margin-bottom: 6px;">📋</div>
                    <div style="font-weight: 600; font-size: 14px; color: #334155;">尚未載入調劑名冊資料</div>
                    <div style="font-size: 12.5px; color: #94a3b8; margin-top: 4px;">
                        可點擊上方「⚡ 載入目錄最新名冊」或「📂 瀏覽上傳其他名冊」載入 Excel/CSV
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    currentRecords.forEach(r => {
        const tr = document.createElement('tr');
        let badgeHtml = '';
        if (r.status_type === 'valid') {
            badgeHtml = `<span class="tag tag-valid">${r.status_desc}</span>`;
        } else if (r.status_type === 'landline') {
            badgeHtml = `<span class="tag tag-landline">市話</span>`;
        } else {
            badgeHtml = `<span class="tag tag-invalid">${r.status_desc}</span>`;
        }

        let sendStatusHtml = '';
        if (r.send_status === 'idle') {
            sendStatusHtml = `<span class="tag tag-pending">待發送</span>`;
        } else if (r.send_status === 'success') {
            sendStatusHtml = `<span class="tag tag-sent">✓ 已發送</span>`;
        } else if (r.send_status === 'failed') {
            sendStatusHtml = `<span class="tag tag-failed" title="${r.send_result}">✗ 失敗</span>`;
        } else if (r.send_status === 'sending') {
            sendStatusHtml = `<span class="tag tag-pending" style="color: #0284c7;">發送中...</span>`;
        }

        let dateScheduleCell = '';
        if (excelTimingMode === 'instant') {
            dateScheduleCell = `<span class="tag" style="background: #ecfdf5; color: #065f46; border: 1px solid #a7f3d0; font-weight: 700; font-size: 12px; padding: 3px 8px;">⚡ 立即發送</span>`;
        } else {
            let dateBadge = '';
            if (r.schedule_moved_from_sunday) {
                dateBadge = `<div style="font-size: 10.5px; color: #b45309; background: #fef3c7; border: 1px solid #fde68a; border-radius: 4px; padding: 1px 5px; margin-top: 3px; font-weight: 700; white-space: nowrap; display: inline-block;">週日 ➔ 週一 09:00</div>`;
            } else if (r.date && excelSchedSubchoice === 'by_dispense_date') {
                dateBadge = `<div style="font-size: 10.5px; color: #0369a1; background: #e0f2fe; border: 1px solid #bae6fd; border-radius: 4px; padding: 1px 5px; margin-top: 3px; font-weight: 600; white-space: nowrap; display: inline-block;">預約當天 09:00</div>`;
            }
            dateScheduleCell = `
                <div style="font-size: 12.5px; color: #0f172a; font-weight: 700;">${r.schedule_display || r.date || '預約發送'}</div>
                ${dateBadge}
            `;
        }

        tr.innerHTML = `
            <td>
                <input type="checkbox" ${r.selected ? 'checked' : ''} ${!r.is_valid_mobile ? 'disabled' : ''} onchange="toggleSelect(${r.id})">
            </td>
            <td>${r.id}</td>
            <td><strong>${r.name}</strong></td>
            <td>${dateScheduleCell}</td>
            <td><code style="font-size: 12px; color: #64748b;">${r.raw_phone}</code></td>
            <td><strong>${r.cleaned_phone || '—'}</strong></td>
            <td>${badgeHtml}</td>
            <td><div style="max-width: 280px; font-size: 12px; line-height: 1.4; color: #334155;">${r.content || '—'}</div></td>
            <td><span style="font-weight: 600; color: ${r.char_count > 70 ? '#d97706' : '#059669'};">${r.char_count || '—'}</span></td>
            <td>${sendStatusHtml}</td>
        `;
        tbody.appendChild(tr);
    });
}

function toggleSelect(id) {
    const item = currentRecords.find(r => r.id === id);
    if (item) {
        item.selected = !item.selected;
        updateSummaryStats();
    }
}

async function loadHistory() {
    const tbody = document.getElementById('history-tbody');
    tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">載入中...</td></tr>';
    try {
        const res = await fetch('/api/history');
        const data = await res.json();
        if (data.success && data.history.length > 0) {
            tbody.innerHTML = '';
            data.history.forEach(h => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="font-size: 11px;">${h.time}</td>
                    <td><strong>${h.name}</strong></td>
                    <td><code>${h.phone}</code></td>
                    <td><span style="font-size: 11px; color: #0284c7;">${h.dsttime || '即時發送'}</span></td>
                    <td><span class="tag ${h.success ? 'tag-sent' : 'tag-failed'}">${h.status}</span></td>
                    <td>${h.point || 0}</td>
                    <td style="font-size: 11px; color: #64748b;">${h.msgid || '—'}</td>
                `;
                tbody.appendChild(tr);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #94a3b8;">尚無發送紀錄</td></tr>';
        }
    } catch (e) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: #dc2626;">載入紀錄失敗</td></tr>';
    }
}

function openModal(id) {
    document.getElementById(id).style.display = 'flex';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

// ==========================================
// 罐頭簡訊管理模組 (自訂新增、編輯、刪除、套用)
// ==========================================

function openTemplateModal(prefillContent = '', prefillName = '') {
    openModal('template-modal');
    if (prefillContent) {
        document.getElementById('tpl-form-content').value = prefillContent;
        document.getElementById('tpl-form-name').value = prefillName || '';
        document.getElementById('tpl-form-old-name').value = prefillName || '';
        if (prefillName) {
            document.getElementById('tpl-form-title-text').textContent = `✏️ 編輯罐頭簡訊「${prefillName}」`;
            document.getElementById('tpl-save-btn-text').textContent = '儲存修改';
            document.getElementById('tpl-reset-btn').style.display = 'inline-block';
        } else {
            document.getElementById('tpl-form-title-text').textContent = '➕ 另存新罐頭簡訊';
            document.getElementById('tpl-save-btn-text').textContent = '儲存為罐頭簡訊';
            document.getElementById('tpl-reset-btn').style.display = 'inline-block';
        }
    } else {
        resetTemplateForm();
    }
    updateTplCharCounter();
    renderTemplateModalList();
    setTimeout(() => {
        const nameInput = document.getElementById('tpl-form-name');
        if (nameInput) nameInput.focus();
    }, 150);
}

function quickSaveAsTemplate() {
    const textarea = document.getElementById('template-textarea');
    const content = textarea ? textarea.value.trim() : '';
    if (!content) {
        alert('請先在簡訊文字框輸入欲儲存的簡訊內容！');
        if (textarea) textarea.focus();
        return;
    }
    openTemplateModal(content);
}

function resetTemplateForm() {
    document.getElementById('tpl-form-old-name').value = '';
    document.getElementById('tpl-form-name').value = '';
    document.getElementById('tpl-form-content').value = '';
    document.getElementById('tpl-form-title-text').textContent = '新增自訂罐頭簡訊';
    document.getElementById('tpl-save-btn-text').textContent = '儲存為罐頭簡訊';
    document.getElementById('tpl-reset-btn').style.display = 'none';
    updateTplCharCounter();
}

function insertTagToTpl(tag) {
    const textarea = document.getElementById('tpl-form-content');
    if (!textarea) return;
    const start = textarea.selectionStart || 0;
    const end = textarea.selectionEnd || 0;
    const text = textarea.value;
    textarea.value = text.substring(0, start) + tag + text.substring(end);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = start + tag.length;
    updateTplCharCounter();
}

function updateTplCharCounter() {
    const content = (document.getElementById('tpl-form-content').value || '');
    const len = content.length;
    const charSpan = document.getElementById('tpl-char-count');
    const ptSpan = document.getElementById('tpl-point-count');
    if (charSpan) charSpan.textContent = len;
    let points = 1;
    if (len > 70) {
        points = Math.ceil(len / 67);
    }
    if (ptSpan) ptSpan.textContent = len === 0 ? 0 : points;
}

function renderTemplateModalList() {
    const container = document.getElementById('tpl-list-container');
    const countSpan = document.getElementById('tpl-list-count');
    if (!container) return;

    const templates = appConfig.saved_templates || [];
    if (countSpan) countSpan.textContent = templates.length;

    if (templates.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 25px; color: #94a3b8; background: #f8fafc; border-radius: 8px; border: 1px dashed #cbd5e1;">
                尚未儲存任何罐頭簡訊，請使用上方表單建立第一筆！
            </div>
        `;
        return;
    }

    container.innerHTML = '';
    templates.forEach((t, index) => {
        const itemLen = t.content.length;
        const pts = itemLen <= 70 ? 1 : Math.ceil(itemLen / 67);
        const card = document.createElement('div');
        card.style.cssText = 'background: #ffffff; border: 1.5px solid #e2e8f0; border-radius: 8px; padding: 12px 16px; transition: border-color 0.2s;';
        
        card.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 6px; gap: 10px;">
                <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
                    <span style="font-weight: 700; font-size: 14.5px; color: #1e293b;">${escapeHtml(t.name)}</span>
                    <span style="font-size: 11px; background: #e0f2fe; color: #0369a1; padding: 2px 8px; border-radius: 4px; font-weight: 600;">
                        ${itemLen} 字 / ${pts} 則
                    </span>
                </div>
                <div style="display: flex; gap: 6px; flex-shrink: 0;">
                    <button type="button" class="btn btn-sm btn-primary" onclick="applyTemplateToEditor(${index})" style="background: #0284c7; border-color: #0284c7; padding: 3px 10px; font-size: 12px; font-weight: 600;">
                        📥 套用
                    </button>
                    <button type="button" class="btn btn-sm btn-outline" onclick="editTemplateInForm(${index})" style="padding: 3px 8px; font-size: 12px;">
                        ✏️ 編輯
                    </button>
                    <button type="button" class="btn btn-sm btn-outline" onclick="deleteTemplateItem('${escapeHtml(t.name)}')" style="padding: 3px 8px; font-size: 12px; color: #dc2626; border-color: #fca5a5;">
                        🗑️ 刪除
                    </button>
                </div>
            </div>
            <div style="font-size: 13px; color: #475569; line-height: 1.5; background: #f8fafc; padding: 8px 12px; border-radius: 6px; border: 1px solid #f1f5f9; word-break: break-all; white-space: pre-wrap;">${escapeHtml(t.content)}</div>
        `;
        container.appendChild(card);
    });
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function applyTemplateToEditor(index) {
    const templates = appConfig.saved_templates || [];
    const t = templates[index];
    if (!t) return;

    const tArea = document.getElementById('template-textarea');
    if (tArea) {
        tArea.value = t.content;
        updateCharCounter();
        if (currentRecords.length > 0) {
            recalculateTemplate();
        }
    }
    renderTemplateSelector(t.name);
    closeModal('template-modal');
}

function editTemplateInForm(index) {
    const templates = appConfig.saved_templates || [];
    const t = templates[index];
    if (!t) return;

    document.getElementById('tpl-form-old-name').value = t.name;
    document.getElementById('tpl-form-name').value = t.name;
    document.getElementById('tpl-form-content').value = t.content;
    document.getElementById('tpl-form-title-text').textContent = `✏️ 編輯罐頭簡訊「${t.name}」`;
    document.getElementById('tpl-save-btn-text').textContent = '儲存修改';
    document.getElementById('tpl-reset-btn').style.display = 'inline-block';

    updateTplCharCounter();

    const formBox = document.getElementById('tpl-form-name');
    if (formBox) {
        formBox.focus();
        formBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

async function submitTemplateForm() {
    const nameInput = document.getElementById('tpl-form-name');
    const contentInput = document.getElementById('tpl-form-content');
    const oldNameInput = document.getElementById('tpl-form-old-name');

    const name = nameInput.value.trim();
    const content = contentInput.value.trim();
    const oldName = oldNameInput.value.trim();

    if (!name) {
        alert('請輸入罐頭簡訊名稱！');
        nameInput.focus();
        return;
    }
    if (!content) {
        alert('請輸入罐頭簡訊內容！');
        contentInput.focus();
        return;
    }

    const saveBtn = document.getElementById('tpl-save-btn');
    const origText = saveBtn.innerHTML;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span>⏳</span> 儲存中...';

    try {
        const res = await fetch('/api/templates', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, content, old_name: oldName })
        });
        const data = await res.json();
        if (data.success) {
            appConfig.saved_templates = data.templates;
            renderTemplateSelector(name);
            resetTemplateForm();
            renderTemplateModalList();
        } else {
            alert(data.error || '儲存失敗，請重試');
        }
    } catch (e) {
        console.error('Submit template error:', e);
        alert('連線失敗，無法儲存罐頭簡訊');
    } finally {
        saveBtn.disabled = false;
        saveBtn.innerHTML = origText;
    }
}

async function deleteTemplateItem(name) {
    if (!confirm(`確定要刪除「${name}」這則罐頭簡訊嗎？`)) {
        return;
    }

    try {
        const res = await fetch('/api/templates', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name })
        });
        const data = await res.json();
        if (data.success) {
            appConfig.saved_templates = data.templates;
            renderTemplateSelector();
            const oldName = document.getElementById('tpl-form-old-name').value;
            if (oldName === name) {
                resetTemplateForm();
            }
            renderTemplateModalList();
        } else {
            alert(data.error || '刪除失敗');
        }
    } catch (e) {
        console.error('Delete template error:', e);
        alert('連線失敗，無法刪除罐頭簡訊');
    }
}

