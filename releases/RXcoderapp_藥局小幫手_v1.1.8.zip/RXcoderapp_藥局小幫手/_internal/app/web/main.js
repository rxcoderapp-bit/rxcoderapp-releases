let currentResult = null;
let currentFilter = 'ALL';
let allPatients = [];
let g_detectedPdfStartDate = '';
let g_detectedPdfEndDate = '';
let g_detectedPdfDateRangeStr = '';

document.addEventListener('DOMContentLoaded', () => {
  loadAvailableFiles();
  document.getElementById('excelSelect').addEventListener('change', onExcelFileChange);
  document.getElementById('pdfSelect').addEventListener('change', autoMatchSheetIfPossible);
});

function toggleDateFilter(forceState = null) {
  const chk = document.getElementById('enableDateFilter');
  const isEnabled = forceState !== null ? forceState : (chk ? chk.checked : true);
  if (chk && forceState !== null) chk.checked = forceState;

  const startInp = document.getElementById('reconcileStartDate');
  const endInp = document.getElementById('reconcileEndDate');
  const btnAuto = document.getElementById('btnAutoDateRange');
  const dateNotice = document.getElementById('dateAutoFillNotice');

  if (startInp) startInp.disabled = !isEnabled;
  if (endInp) endInp.disabled = !isEnabled;
  if (btnAuto) btnAuto.disabled = !isEnabled;

  if (!isEnabled) {
    if (dateNotice) {
      dateNotice.innerHTML = `<span style="color:#64748B;">（全選模式：比對 Excel 內所有歷史年份與月份）</span>`;
    }
  } else {
    onDateRangeManualChange();
  }
}

function applyPdfDateRange() {
  if (g_detectedPdfStartDate && g_detectedPdfEndDate) {
    const startInp = document.getElementById('reconcileStartDate');
    const endInp = document.getElementById('reconcileEndDate');
    if (startInp) startInp.value = g_detectedPdfStartDate;
    if (endInp) endInp.value = g_detectedPdfEndDate;
    const chk = document.getElementById('enableDateFilter');
    if (chk) chk.checked = true;
    toggleDateFilter(true);
    const dateNotice = document.getElementById('dateAutoFillNotice');
    if (dateNotice) {
      dateNotice.innerHTML = `<span>✨ 已帶入 PDF 區間：<strong>${escapeHtml(g_detectedPdfDateRangeStr)}</strong></span>`;
    }
  } else {
    alert('目前 PDF 尚未辨識出有效日期區間，請直接手動輸入開始與結束日期（例如：115/08/01）。');
  }
}

function clearDateFilter() {
  const chk = document.getElementById('enableDateFilter');
  if (chk) chk.checked = false;
  toggleDateFilter(false);
}

function onDateRangeManualChange() {
  const s = document.getElementById('reconcileStartDate')?.value.trim();
  const e = document.getElementById('reconcileEndDate')?.value.trim();
  const dateNotice = document.getElementById('dateAutoFillNotice');
  if (dateNotice) {
    if (s || e) {
      dateNotice.innerHTML = `<span style="color:#0284C7;">🎯 目前設定勾稽區間：<strong>${escapeHtml(s || '不限')} ～ ${escapeHtml(e || '不限')}</strong></span>`;
    } else {
      dateNotice.innerHTML = `<span>（未設定具體日期，將比對全期）</span>`;
    }
  }
}


async function loadAvailableFiles() {
  try {
    const res = await fetch('/api/available-files');
    const data = await res.json();
    
    const pdfSelect = document.getElementById('pdfSelect');
    const excelSelect = document.getElementById('excelSelect');
    
    pdfSelect.innerHTML = '';
    excelSelect.innerHTML = '';
    
    if (data.pdfs.length === 0) {
      pdfSelect.innerHTML = '<option value="">目錄中無 PDF 檔案</option>';
    } else {
      data.pdfs.forEach(f => {
        const opt = document.createElement('option');
        opt.value = f.path;
        opt.textContent = `${f.filename} (${f.size})`;
        pdfSelect.appendChild(opt);
      });
    }

    if (data.excels.length === 0) {
      excelSelect.innerHTML = '<option value="">目錄中無 Excel 檔案</option>';
    } else {
      data.excels.forEach(f => {
        const opt = document.createElement('option');
        opt.value = f.path;
        opt.textContent = `${f.filename} (${f.size})`;
        excelSelect.appendChild(opt);
      });

      // Automatically restore user's last active Excel if available
      try {
        const savedExcel = localStorage.getItem('active_excel_path');
        if (savedExcel && Array.from(excelSelect.options).some(o => o.value === savedExcel)) {
          excelSelect.value = savedExcel;
        }
      } catch (e) {}

      // Trigger sheet loading for active excel file
      onExcelFileChange();
    }
  } catch (err) {
    console.error('載入檔案清單失敗:', err);
  }
}

async function onExcelFileChange() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetSelect = document.getElementById('sheetSelect');
  if (!excelPath) {
    sheetSelect.innerHTML = '<option value="">請先選擇 Excel 檔案</option>';
    return;
  }

  try {
    localStorage.setItem('active_excel_path', excelPath);
  } catch (e) {}
  
  sheetSelect.innerHTML = '<option value="">正在讀取工作表清單...</option>';
  try {
    const res = await fetch(`/api/sheets?excel_path=${encodeURIComponent(excelPath)}`);
    const data = await res.json();
    if (data.path && data.path !== excelPath) {
      const opt = Array.from(document.getElementById('excelSelect').options).find(o => o.value === excelPath);
      if (opt) {
        opt.value = data.path;
      }
      document.getElementById('excelSelect').value = data.path;
      try {
        localStorage.setItem('active_excel_path', data.path);
      } catch (e) {}
    }
    sheetSelect.innerHTML = '';
    
    data.sheets.forEach(s => {
      const opt = document.createElement('option');
      opt.value = s.sheet_name;
      opt.textContent = s.sheet_name + (s.drug_name ? ` (${s.drug_name})` : '');
      sheetSelect.appendChild(opt);
    });
    
    autoMatchSheetIfPossible();
  } catch (err) {
    sheetSelect.innerHTML = '<option value="">讀取工作表失敗</option>';
  }
}

async function autoMatchSheetIfPossible() {
  const pdfSelect = document.getElementById('pdfSelect');
  const excelSelect = document.getElementById('excelSelect');
  const sheetSelect = document.getElementById('sheetSelect');
  if (!pdfSelect || !excelSelect || !sheetSelect) return;

  const pdfPath = pdfSelect.value;
  const excelPath = excelSelect.value;
  if (!pdfPath || !excelPath || sheetSelect.options.length === 0) return;

  const sheetHint = document.getElementById('sheetHint');

  // 1. Try deep content match via server API
  try {
    const res = await fetch(`/api/pdf-info?pdf_path=${encodeURIComponent(pdfPath)}&excel_path=${encodeURIComponent(excelPath)}`);
    const data = await res.json();

    // Auto populate date range from PDF if detected
    if (data.success && data.meta && data.meta.start_date && data.meta.end_date) {
      g_detectedPdfStartDate = data.meta.start_date;
      g_detectedPdfEndDate = data.meta.end_date;
      g_detectedPdfDateRangeStr = data.meta.date_range_str || `${data.meta.start_date} ～ ${data.meta.end_date}`;

      const startInp = document.getElementById('reconcileStartDate');
      const endInp = document.getElementById('reconcileEndDate');
      const dateNotice = document.getElementById('dateAutoFillNotice');
      const chk = document.getElementById('enableDateFilter');

      if (startInp && endInp) {
        startInp.value = data.meta.start_date;
        endInp.value = data.meta.end_date;
        if (chk) chk.checked = true;
        toggleDateFilter(true);
      }
      if (dateNotice) {
        dateNotice.innerHTML = `<span>✨ 已自動由 PDF 辨識區間：<strong>${escapeHtml(g_detectedPdfDateRangeStr)}</strong></span>`;
      }
    }

    if (data.success && data.suggested_sheet) {
      for (let i = 0; i < sheetSelect.options.length; i++) {
        if (sheetSelect.options[i].value === data.suggested_sheet) {
          sheetSelect.selectedIndex = i;
          if (sheetHint) {
            sheetHint.innerHTML = `<span style="color:#2E7D32; font-weight:700;">🎯 自動辨識藥品成功：已為您選取【${escapeHtml(data.suggested_sheet)}】(${escapeHtml(data.suggested_reason)})</span>`;
          }
          return;
        }
      }
    }
  } catch (err) {
    console.warn('自動藥品比對 API 查詢失敗，降級使用檔名關鍵字比對', err);
  }

  // 2. Fallback to filename keywords
  const pdfName = pdfSelect.selectedOptions[0]?.textContent || '';
  const cleanPdf = pdfName.replace(/\[已上傳\]/g, '').replace(/\[本機上傳\]/g, '').replace(/\([^\)]*\)/g, '').trim();
  const words = cleanPdf.split(/[\s_\-\.]+/).filter(w => w.length >= 3 && !['VISUAL', 'FOXPRO', 'REPORT'].includes(w.toUpperCase()));
  
  for (let i = 0; i < sheetSelect.options.length; i++) {
    const optText = sheetSelect.options[i].textContent.toUpperCase();
    const optVal = sheetSelect.options[i].value.toUpperCase();
    for (const w of words) {
      const upperW = w.toUpperCase();
      if (optVal.includes(upperW) || optText.includes(upperW)) {
        sheetSelect.selectedIndex = i;
        if (sheetHint) {
          sheetHint.innerHTML = `<span style="color:#2E7D32; font-weight:600;">✨ 檔名配對工作表：${escapeHtml(sheetSelect.options[i].value)}</span>`;
        }
        return;
      }
    }
  }
}

async function handlePdfUpload(e) {
  const file = e.target.files[0];
  if (!file) return;
  
  const formData = new FormData();
  formData.append('file', file);
  
  const badge = document.getElementById('pdfUploadBadge');
  badge.style.display = 'inline-flex';
  badge.textContent = `正在上傳 ${file.name}...`;
  
  try {
    const res = await fetch('/api/upload-pdf', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '上傳失敗');
    
    const pdfSelect = document.getElementById('pdfSelect');
    let opt = Array.from(pdfSelect.options).find(o => o.value === data.path);
    if (!opt) {
      opt = document.createElement('option');
      opt.value = data.path;
      pdfSelect.insertBefore(opt, pdfSelect.firstChild);
    }
    opt.textContent = `[本機上傳] ${data.filename} (${data.size})`;
    pdfSelect.value = data.path;
    
    badge.textContent = `✅ 已載入本地 PDF：${data.filename} (${data.size})`;
    autoMatchSheetIfPossible();
  } catch (err) {
    alert('上傳 PDF 失敗：' + err.message);
    badge.style.display = 'none';
  }
}

async function handleExcelUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('file', file);

  const badge = document.getElementById('excelUploadBadge');
  if (badge) {
    badge.style.display = 'inline-flex';
    badge.textContent = `正在匯入並解析簿冊 ${file.name}...`;
  }

  try {
    const res = await fetch('/api/upload-excel', {
      method: 'POST',
      body: formData
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '匯入失敗');

    // 1. Update excelSelect on main page
    const excelSelect = document.getElementById('excelSelect');
    let opt = Array.from(excelSelect.options).find(o => o.value === data.path);
    if (!opt) {
      opt = document.createElement('option');
      opt.value = data.path;
      excelSelect.insertBefore(opt, excelSelect.firstChild);
    }
    opt.textContent = `[已匯入] ${data.filename} (${data.size})`;
    excelSelect.value = data.path;

    // Remember in localStorage
    try {
      localStorage.setItem('active_excel_path', data.path);
    } catch (err) {}

    // 2. Populate main sheetSelect
    const sheetSelect = document.getElementById('sheetSelect');
    sheetSelect.innerHTML = '';
    data.sheets.forEach(s => {
      const sOpt = document.createElement('option');
      sOpt.value = s.sheet_name;
      sOpt.textContent = s.sheet_name + (s.drug_name ? ` (${s.drug_name})` : '');
      sheetSelect.appendChild(sOpt);
    });

    if (badge) {
      badge.textContent = `✅ 成功匯入簿冊：${data.filename} (${data.size}，含 ${data.sheets.length} 個藥品分頁)`;
    }

    // 3. Update registry sheet selector in modal
    const regSheetSelect = document.getElementById('regSheetSelect');
    if (regSheetSelect) {
      regSheetSelect.innerHTML = '';
      data.sheets.forEach(s => {
        const rOpt = document.createElement('option');
        rOpt.value = s.sheet_name;
        rOpt.textContent = s.sheet_name + (s.drug_name ? ` (${s.drug_name})` : '');
        regSheetSelect.appendChild(rOpt);
      });
      if (data.sheets.length > 0) {
        regSheetSelect.value = data.sheets[0].sheet_name;
      }
    }

    // 4. Background patient autocomplete load for this newly imported excel
    loadPatientsForAutocomplete(data.path);

    // 5. If registry modal is currently open, reload data immediately
    const regModal = document.getElementById('registryModal');
    if (regModal && regModal.style.display === 'flex') {
      loadRegistryData();
      const regAlert = document.getElementById('regAlertArea');
      if (regAlert) {
        regAlert.innerHTML = `
          <div class="alert alert-success" style="padding:10px 14px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;">
            <span>🎉 成功匯入簿冊「${escapeHtml(data.filename)}」！已自動載入 ${data.sheets.length} 個藥品分頁，後續登錄與增刪修將直接同步寫入此 Excel！</span>
            <button class="btn-close" onclick="this.parentElement.remove()">&times;</button>
          </div>
        `;
      }
    } else {
      alert(`🎉 成功匯入既有管藥簿冊：\n${data.filename}\n\n已自動辨識出 ${data.sheets.length} 個管制藥品分頁！\n藥品選單已同步更新，後續登錄、新增、修改或刪除藥品皆會直接同步寫入此 Excel 檔案。`);
    }

    autoMatchSheetIfPossible();
  } catch (err) {
    alert('匯入 Excel 失敗：' + err.message);
    if (badge) badge.style.display = 'none';
  } finally {
    e.target.value = '';
  }
}


async function startReconciliation() {
  const pdfPath = document.getElementById('pdfSelect').value;
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  
  if (!pdfPath || !excelPath || !sheetName) {
    alert('請完整選擇 PDF 清冊、Excel 檔案與藥品工作表！');
    return;
  }
  
  const btn = document.getElementById('btnReconcile');
  const loader = document.getElementById('loadingStatus');
  btn.disabled = true;
  loader.style.display = 'inline-flex';
  
  const isDateFilterEnabled = document.getElementById('enableDateFilter') ? document.getElementById('enableDateFilter').checked : false;
  const startDate = document.getElementById('reconcileStartDate') ? document.getElementById('reconcileStartDate').value.trim() : '';
  const endDate = document.getElementById('reconcileEndDate') ? document.getElementById('reconcileEndDate').value.trim() : '';

  try {
    const res = await fetch('/api/reconcile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pdf_path: pdfPath,
        excel_path: excelPath,
        sheet_name: sheetName,
        filter_date_range: isDateFilterEnabled,
        start_date: isDateFilterEnabled ? startDate : '',
        end_date: isDateFilterEnabled ? endDate : ''
      })
    });
    
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || '對帳發生錯誤');
    }
    
    currentResult = data;
    allPatients = data.patient_reports;
    renderResults(data);
    document.getElementById('btnExport').disabled = false;
  } catch (err) {
    alert('對帳失敗：' + err.message);
  } finally {
    btn.disabled = false;
    loader.style.display = 'none';
  }
}

function renderResults(data) {
  const area = document.getElementById('resultsArea');
  area.style.display = 'block';

  // Check and render sheet mismatch warning banner
  let alertEl = document.getElementById('sheetMismatchAlert');
  if (data.sheet_warning) {
    if (!alertEl) {
      alertEl = document.createElement('div');
      alertEl.id = 'sheetMismatchAlert';
      area.insertBefore(alertEl, area.firstChild);
    }
    alertEl.innerHTML = `
      <div class="alert alert-warning" style="background:#FFF8E1; border:2px solid #FFA000; color:#5D4037; padding:16px 20px; border-radius:10px; margin-bottom:20px; box-shadow:0 4px 12px rgba(255,160,0,0.15);">
        <div style="display:flex; align-items:flex-start; gap:12px;">
          <span style="font-size:24px;">⚠️</span>
          <div style="flex:1;">
            <div style="font-size:16px; font-weight:800; color:#E65100; margin-bottom:6px;">
              偵測到工作表選取可能不正確（導致 Excel 查無登記紀錄）！
            </div>
            <div style="font-size:14px; line-height:1.6; color:#4E342E;">
              ${escapeHtml(data.sheet_warning.message)}
            </div>
            <div style="margin-top:12px; display:flex; gap:10px; align-items:center;">
              <button type="button" class="btn btn-primary" onclick="switchToSheetAndReconcile('${escapeHtml(data.sheet_warning.suggested_sheet)}')" style="font-size:14px; padding:7px 16px; font-weight:700; background:#E65100; border-color:#BF360C;">
                👉 立即切換至【${escapeHtml(data.sheet_warning.suggested_sheet)}】重新對帳
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  } else if (alertEl) {
    alertEl.remove();
  }
  
  const sum = data.summary;

  // Render Date Filter Result Notice Banner
  const noticeEl = document.getElementById('dateFilterResultNotice');
  if (noticeEl) {
    if (sum.date_filter_applied) {
      noticeEl.style.display = 'block';
      noticeEl.innerHTML = `
        <div style="background:#F0FDF4; border:1.5px solid #86EFAC; color:#166534; padding:12px 18px; border-radius:8px; margin-bottom:18px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; box-shadow:0 2px 6px rgba(16,185,129,0.08);">
          <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size:22px;">📅</span>
            <div>
              <div style="font-weight:800; font-size:14.5px; color:#14532D;">
                已依指定日期區間精準勾稽：${escapeHtml(sum.filter_date_range_str)}
              </div>
              <div style="font-size:12.5px; color:#15803D; margin-top:2px;">
                系統已自動排除非本期之歷史登記紀錄 <strong>${sum.excluded_excel_count}</strong> 筆（計 <strong>${sum.excluded_excel_qty.toLocaleString()}</strong> 顆），差額僅統計此區間！
              </div>
            </div>
          </div>
          <span style="font-size:12px; background:#DCFCE7; border:1px solid #86EFAC; color:#166534; font-weight:700; padding:4px 10px; border-radius:6px;">
            區間勾稽啟用中
          </span>
        </div>
      `;
    } else {
      noticeEl.style.display = 'none';
      noticeEl.innerHTML = '';
    }
  }

  // KPI Qty Result
  const kpiQtyResult = document.getElementById('kpiQtyResult');
  const kpiTotal = document.getElementById('kpiTotal');
  if (sum.qty_diff === 0) {
    kpiQtyResult.textContent = '完全吻合 ✅';
    kpiQtyResult.className = 'kpi-value text-success';
  } else {
    kpiQtyResult.textContent = `差額 ${sum.qty_diff > 0 ? '+' : ''}${sum.qty_diff} 顆 ⚠️`;
    kpiQtyResult.className = 'kpi-value text-danger';
  }

  if (sum.date_filter_applied && sum.excluded_excel_count > 0) {
    document.getElementById('kpiQtyDetail').innerHTML = `本期 PDF ${sum.total_pdf_qty.toLocaleString()} 顆 vs Excel ${sum.total_excel_qty.toLocaleString()} 顆 <span style="display:block; font-size:11px; color:#64748B; margin-top:2px;">(全期 Excel 共 ${sum.raw_total_excel_qty.toLocaleString()} 顆，已排除 ${sum.excluded_excel_qty.toLocaleString()} 顆)</span>`;
  } else {
    document.getElementById('kpiQtyDetail').textContent = `PDF ${sum.total_pdf_qty.toLocaleString()} 顆 vs Excel ${sum.total_excel_qty.toLocaleString()} 顆`;
  }
  
  // KPI Counts
  document.getElementById('kpiMatchedCount').textContent = sum.matched_patients;
  document.getElementById('kpiTypoCount').textContent = sum.typo_patients;
  document.getElementById('kpiDiffCount').textContent = (sum.qty_mismatch_patients + sum.missing_patients);
  
  // Tab Badges
  document.getElementById('countAll').textContent = allPatients.length;
  document.getElementById('countDiff').textContent = sum.qty_mismatch_patients;
  document.getElementById('countTypo').textContent = sum.typo_patients;
  document.getElementById('countMissing').textContent = sum.missing_patients;
  document.getElementById('countOk').textContent = sum.matched_patients;
  
  applyFilterAndRender();
}

function switchToSheetAndReconcile(targetSheet) {
  const sheetSelect = document.getElementById('sheetSelect');
  if (sheetSelect) {
    for (let i = 0; i < sheetSelect.options.length; i++) {
      if (sheetSelect.options[i].value === targetSheet) {
        sheetSelect.selectedIndex = i;
        break;
      }
    }
    startReconciliation();
  }
}

function setFilter(filterType) {
  currentFilter = filterType;
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  event.target.closest('.tab-btn').classList.add('active');
  applyFilterAndRender();
}

function handleSearch() {
  applyFilterAndRender();
}

function applyFilterAndRender() {
  const query = document.getElementById('searchInput').value.trim().toLowerCase();
  
  let list = allPatients.filter(p => {
    // Tab filter
    if (currentFilter === 'DIFF' && p.status !== 'DIFF') return false;
    if (currentFilter === 'TYPO' && p.status !== 'TYPO') return false;
    if (currentFilter === 'MISSING' && !p.status.startsWith('MISSING')) return false;
    if (currentFilter === 'OK' && p.status !== 'OK') return false;
    
    // Search query filter
    if (query) {
      const matchName = (p.name || '').toLowerCase().includes(query) || (p.pdf_name || '').toLowerCase().includes(query) || (p.excel_name || '').toLowerCase().includes(query);
      const matchId = (p.pdf_id || '').toLowerCase().includes(query) || (p.excel_id || '').toLowerCase().includes(query);
      return matchName || matchId;
    }
    return true;
  });
  
  renderTable(list);
}

function renderTable(list) {
  const tbody = document.getElementById('tableBody');
  tbody.innerHTML = '';
  
  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="10" class="text-center" style="padding: 30px; color: var(--ink-2);">無符合條件的病患記錄</td></tr>`;
    return;
  }
  
  list.forEach((p, idx) => {
    const tr = document.createElement('tr');
    
    // Status Pill
    let pillHtml = '';
    if (p.status === 'OK') {
      pillHtml = '<span class="pill pill-ok">完全吻合</span>';
    } else if (p.status === 'TYPO') {
      pillHtml = '<span class="pill pill-typo">資料瑕疵</span>';
    } else if (p.status === 'DIFF') {
      pillHtml = '<span class="pill pill-diff">數量不符</span>';
    } else {
      pillHtml = '<span class="pill pill-missing">單邊遺漏</span>';
    }
    
    // Diff formatting
    let diffStr = '-';
    let diffClass = '';
    if (p.diff !== 0) {
      diffStr = (p.diff > 0 ? '+' : '') + p.diff;
      diffClass = p.diff > 0 ? 'text-danger' : 'text-danger';
    } else {
      diffStr = '0';
      diffClass = 'text-success';
    }
    
    tr.innerHTML = `
      <td>${pillHtml}</td>
      <td><strong>${escapeHtml(p.name)}</strong></td>
      <td>${escapeHtml(p.pdf_id)}</td>
      <td>${escapeHtml(p.excel_id)}</td>
      <td class="text-right"><strong>${p.pdf_qty}</strong></td>
      <td class="text-right"><strong>${p.excel_qty}</strong></td>
      <td class="text-right ${diffClass}"><strong>${diffStr}</strong></td>
      <td class="text-center">${p.pdf_tx_count} / ${p.excel_tx_count}</td>
      <td style="font-size: 13px; color: var(--ink-2);">${escapeHtml(p.status_desc)}</td>
      <td class="text-center">
        <button class="btn-detail" onclick="openDrillModal('${encodeURIComponent(p.key)}')">查看</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function openDrillModal(encodedKey) {
  const key = decodeURIComponent(encodedKey);
  const patient = allPatients.find(p => p.key === key);
  if (!patient) return;
  
  document.getElementById('modalTitle').textContent = `病患：${patient.name} 調劑對照穿透明細`;
  document.getElementById('modalSub').textContent = `PDF 身分證：${patient.pdf_id} ｜ Excel 身分證：${patient.excel_id} ｜ 總數量：PDF ${patient.pdf_qty} 顆 vs Excel ${patient.excel_qty} 顆`;
  
  // Left: PDF records
  const pdfBody = document.getElementById('pdfDrillBody');
  pdfBody.innerHTML = '';
  if (patient.pdf_transactions.length === 0) {
    pdfBody.innerHTML = '<tr><td colspan="4" class="text-center" style="padding:15px; color:#888;">無 PDF 電腦調劑明細</td></tr>';
  } else {
    patient.pdf_transactions.forEach(t => {
      const r = document.createElement('tr');
      r.innerHTML = `
        <td>${t.dispense_date}</td>
        <td><strong>${t.qty}</strong></td>
        <td>${escapeHtml(t.clinic || '-')}</td>
        <td>P.${t.page}</td>
      `;
      pdfBody.appendChild(r);
    });
  }
  
  // Right: Excel records
  const excelBody = document.getElementById('excelDrillBody');
  excelBody.innerHTML = '';
  if (patient.excel_transactions.length === 0) {
    excelBody.innerHTML = '<tr><td colspan="5" class="text-center" style="padding:15px; color:#888;">無 Excel 門市登記明細</td></tr>';
  } else {
    patient.excel_transactions.forEach(t => {
      const r = document.createElement('tr');
      r.innerHTML = `
        <td>${t.date || '-'}</td>
        <td><strong>${t.qty}</strong></td>
        <td>${escapeHtml(t.raw_person || '-')}</td>
        <td>第 ${t.row} 列</td>
        <td>${t.balance !== null ? t.balance : '-'}</td>
      `;
      excelBody.appendChild(r);
    });
  }
  
  document.getElementById('drillModal').style.display = 'flex';
}

function closeModal() {
  document.getElementById('drillModal').style.display = 'none';
}

async function exportReport() {
  if (!currentResult) return;
  const btn = document.getElementById('btnExport');
  btn.disabled = true;
  btn.textContent = '正在匯出...';
  
  try {
    const res = await fetch('/api/export-excel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        result_data: currentResult,
        pdf_meta: currentResult.pdf_meta,
        excel_meta: currentResult.excel_meta
      })
    });
    
    if (!res.ok) throw new Error('匯出失敗');
    
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `管藥對帳報告_${currentResult.excel_meta.sheet_name}_${new Date().toISOString().slice(0,10)}.xlsx`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } catch (err) {
    alert('匯出 Excel 報告失敗：' + err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg> 匯出完整 Excel 覆核報告`;
  }
}

function escapeHtml(text) {
  if (!text) return '';
  return String(text)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ----------------------------------------------------
// Automation Module 1: FIFO Dynamic Balance
// ----------------------------------------------------
async function openFifoModal() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  if (!excelPath || !sheetName) {
    alert('請先在畫面上方選擇 Excel 檔案與藥品工作表！');
    return;
  }

  const modal = document.getElementById('fifoModal');
  modal.style.display = 'flex';
  
  const alertArea = document.getElementById('fifoAlertArea');
  const tbody = document.getElementById('fifoTableBody');
  alertArea.innerHTML = '';
  tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding:20px;">正在進行智慧動態結存鏈與 FIFO 扣帳計算...</td></tr>';
  
  try {
    const res = await fetch(`/api/inventory/ledger?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '讀取結存失敗');

    const meta = data.meta || {};
    document.getElementById('fifoDrugName').textContent = meta.drug_name || sheetName;
    document.getElementById('fifoInitBalance').textContent = meta.initial_balance ?? 0;
    
    let totalIn = 0;
    let totalOut = 0;
    data.transactions.forEach(t => {
      if (t.reason !== '上月結存' && t.reason !== '期初結存') {
        totalIn += (t.in_qty || 0);
      }
      totalOut += (t.out_qty || 0);
    });
    document.getElementById('fifoTotalIn').textContent = totalIn;
    document.getElementById('fifoTotalOut').textContent = totalOut;
    document.getElementById('fifoFinalBalance').textContent = data.summary?.ending_balance ?? 0;

    // Deficit alert banner
    if (data.summary?.has_deficit) {
      alertArea.innerHTML = `
        <div class="alert-banner alert-danger">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
          <strong>法規稽核警告：</strong> 偵測到調劑歷史中存在「結存小於 0」之透支異常！請優先核對進貨發票日期是否晚於調劑日。
        </div>
      `;
    } else {
      alertArea.innerHTML = `
        <div class="alert-banner alert-success">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
          <strong>稽核防呆檢核通過：</strong> 歷程動態結存數值恆大於等於 0，符合衛生福利部先進先出（FIFO）批號查驗要求。
        </div>
      `;
    }

    tbody.innerHTML = '';
    data.transactions.forEach((t, i) => {
      const tr = document.createElement('tr');
      const isDeficit = (t.balance_qty < 0);
      const isBeg = (t.reason === '上月結存' || t.reason === '期初結存');
      
      let lotHtml = '-';
      if (t.lot_deductions && t.lot_deductions.length > 0) {
        lotHtml = t.lot_deductions.map(l => `<span class="lot-tag">${escapeHtml(l.lot_number)}: -${l.deducted_qty}</span>`).join(' ');
      } else if (t.lot_number) {
        lotHtml = `<span class="lot-tag">進貨批號: ${escapeHtml(t.lot_number)}</span>`;
      } else if (t.voucher) {
        lotHtml = `<span class="lot-tag">憑證: ${escapeHtml(t.voucher)}</span>`;
      }

      const pillClass = isBeg ? 'pill-primary' : (t.in_qty > 0 ? 'pill-ok' : 'pill-diff');

      tr.innerHTML = `
        <td>${i + 1}</td>
        <td>${escapeHtml(t.date || '-')}</td>
        <td><span class="pill ${pillClass}">${escapeHtml(t.reason || '-')}</span></td>
        <td class="text-right text-success">${(!isBeg && t.in_qty > 0) ? '+' + t.in_qty : '-'}</td>
        <td class="text-right text-danger">${t.out_qty > 0 ? '-' + t.out_qty : '-'}</td>
        <td class="text-right ${isDeficit ? 'text-danger' : ''}" style="font-weight:700;">
          ${t.balance_qty} ${isDeficit ? '⚠️' : ''}
        </td>
        <td>${lotHtml}</td>
        <td>${escapeHtml(t.recipient || t.name || t.person || '-')}</td>
        <td>${escapeHtml(t.voucher || t.rx_number || t.id || '-')}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-danger" style="padding:20px;">載入失敗：${escapeHtml(err.message)}</td></tr>`;
  }
}

function closeFifoModal() {
  document.getElementById('fifoModal').style.display = 'none';
}

// ----------------------------------------------------
// Automation Module 2: Official TFDA Ledger
// ----------------------------------------------------
function openOfficialLedgerModal() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  if (!excelPath || !sheetName) {
    alert('請先在畫面上方選擇 Excel 檔案與藥品工作表！');
    return;
  }

  const modal = document.getElementById('officialLedgerModal');
  const iframe = document.getElementById('officialIframe');
  iframe.src = `/api/official-ledger/print?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}`;
  modal.style.display = 'flex';
}

function closeOfficialLedgerModal() {
  document.getElementById('officialLedgerModal').style.display = 'none';
  document.getElementById('officialIframe').src = 'about:blank';
}

function printOfficialIframe() {
  const iframe = document.getElementById('officialIframe');
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.focus();
    iframe.contentWindow.print();
  }
}

function downloadOfficialExcel() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  if (!excelPath || !sheetName) return;
  window.open(`/api/official-ledger/export?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}`, '_blank');
}

// ----------------------------------------------------
// Automation Module 3: Periodic Declaration Report
// ----------------------------------------------------
async function openPeriodicReportModal() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  if (!excelPath || !sheetName) {
    alert('請先在畫面上方選擇 Excel 檔案與藥品工作表！');
    return;
  }

  document.getElementById('periodicReportModal').style.display = 'flex';
  loadPeriodicReport();
}

async function loadPeriodicReport() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('sheetSelect').value;
  const tbody = document.getElementById('periodicReportBody');
  tbody.innerHTML = '<tr><td colspan="7" class="text-center" style="padding:20px;">正在彙總定期申報統計資料...</td></tr>';

  try {
    const res = await fetch(`/api/official-ledger/report?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '彙總失敗');

    const meta = data.meta || {};
    const rep = data.report || {};

    tbody.innerHTML = `
      <tr>
        <td><strong>${escapeHtml(meta.drug_name || sheetName)}</strong></td>
        <td class="text-center"><span class="pill pill-ok">第 ${meta.control_level || 4} 級</span></td>
        <td class="text-right"><strong>${rep.initial_balance}</strong></td>
        <td class="text-right text-success"><strong>+${rep.total_in}</strong></td>
        <td class="text-right text-danger"><strong>-${rep.total_out}</strong></td>
        <td class="text-right" style="color:var(--accent); font-weight:700;"><strong>${rep.ending_balance}</strong></td>
        <td class="text-center">
          ${rep.ending_balance >= 0 ? '<span class="pill pill-ok">✅ 結存正常</span>' : '<span class="pill pill-diff">⚠️ 負數異常</span>'}
        </td>
      </tr>
    `;
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger" style="padding:20px;">載入失敗：${escapeHtml(err.message)}</td></tr>`;
  }
}

function closePeriodicReportModal() {
  document.getElementById('periodicReportModal').style.display = 'none';
}

// ----------------------------------------------------
// Automation Module 4: Backup & Snapshot Center
// ----------------------------------------------------
async function openBackupModal() {
  document.getElementById('backupModal').style.display = 'flex';
  loadBackupList();
}

function closeBackupModal() {
  document.getElementById('backupModal').style.display = 'none';
}

async function loadBackupList() {
  const listBody = document.getElementById('snapshotListBody');
  const usbText = document.getElementById('usbStatusText');
  const btnUsb = document.getElementById('btnUsbSync');

  listBody.innerHTML = '<div style="padding:20px; text-align:center; color:var(--ink-2);">正在讀取快照紀錄與偵測 USB 隨身碟...</div>';

  try {
    const res = await fetch('/api/backups/list');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '讀取備份資料失敗');

    // USB Drives display
    if (data.usb_drives && data.usb_drives.length > 0) {
      const drivesStr = data.usb_drives.map(d => `${d.letter} [${d.type}]`).join(', ');
      usbText.innerHTML = `✅ 已偵測到外接隨身碟：<strong>${drivesStr}</strong>，可執行即時鏡像雙重備份！`;
      btnUsb.disabled = false;
    } else {
      usbText.innerHTML = `ℹ️ 目前未插入外接 USB 隨身碟，系統仍會進行本地 30 天輪替安全備份。`;
      btnUsb.disabled = true;
    }

    // Snapshots list
    if (!data.snapshots || data.snapshots.length === 0) {
      listBody.innerHTML = '<div style="padding:20px; text-align:center; color:var(--ink-2);">目前尚無時間點快照，系統將在每次寫入對帳時自動產製。</div>';
    } else {
      listBody.innerHTML = '';
      data.snapshots.forEach(s => {
        const item = document.createElement('div');
        item.className = 'backup-card';
        item.innerHTML = `
          <div class="backup-info">
            <h5>${escapeHtml(s.reason || '快照存檔')}</h5>
            <p>時間：${s.timestamp} ｜ 包含明細：${s.item_count || 0} 筆 ｜ 快照編號：${s.id}</p>
          </div>
          <div>
            <button class="btn btn-secondary" style="padding: 6px 12px; font-size: 12.5px;" onclick="rollbackSnapshot('${s.id}')">
              ⏪ 一鍵還原
            </button>
          </div>
        `;
        listBody.appendChild(item);
      });
    }
  } catch (err) {
    listBody.innerHTML = `<div style="padding:20px; text-align:center; color:var(--danger);">讀取失敗：${escapeHtml(err.message)}</div>`;
  }
}

async function rollbackSnapshot(snapId) {
  if (!confirm(`確定要將管制藥帳冊秒級還原至此時間點快照 (${snapId}) 嗎？\n此動作將復原當時之完整結存狀態。`)) {
    return;
  }

  try {
    const res = await fetch('/api/backups/rollback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ snap_id: snapId })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '還原失敗');
    alert(`✅ 已成功秒級還原至快照 [${snapId}]！`);
    loadBackupList();
  } catch (err) {
    alert('還原失敗：' + err.message);
  }
}

async function triggerImmediateBackup(syncUsb) {
  try {
    const res = await fetch('/api/backups/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '備份失敗');
    
    let msg = `✅ 本地輪替備份成功！\n備份檔名：${data.backup_file}\n已保留最近 ${data.rotation_kept} 份歷史備份。`;
    if (syncUsb) {
      if (data.usb_sync?.success) {
        msg += `\n\n💾 USB 隨身碟鏡像備份成功！同步至 ${data.usb_sync.target_dir}`;
      } else {
        msg += `\n\nℹ️ USB 隨身碟狀態：${data.usb_sync?.message || '未同步'}`;
      }
    }
    alert(msg);
    loadBackupList();
  } catch (err) {
    alert('執行備份失敗：' + err.message);
  }
}

// ----------------------------------------------------
// Automation Module 5: Direct In-App Ledger Registry
// ----------------------------------------------------
let cachedPatients = [];
let activeTypeaheadIndex = -1;
let currentRegBalance = 0;

function formatRocDate(d) {
  const y = d.getFullYear() - 1911;
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}/${m}/${day}`;
}

function setRegDateToday() {
  document.getElementById('regDate').value = formatRocDate(new Date());
}

function setRegDateYesterday() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  document.getElementById('regDate').value = formatRocDate(d);
}

async function openRegistryModal() {
  const excelSelect = document.getElementById('excelSelect');
  const sheetSelect = document.getElementById('sheetSelect');
  const excelPath = excelSelect.value;
  if (!excelPath) {
    alert('請先在畫面上方選擇欲登錄的管制藥 Excel 檔案！');
    return;
  }

  // Populate sheet selector in modal
  const regSheetSelect = document.getElementById('regSheetSelect');
  regSheetSelect.innerHTML = '';
  Array.from(sheetSelect.options).forEach(opt => {
    if (opt.value) {
      const o = document.createElement('option');
      o.value = opt.value;
      o.textContent = opt.textContent;
      regSheetSelect.appendChild(o);
    }
  });

  if (sheetSelect.value) {
    regSheetSelect.value = sheetSelect.value;
  }

  // Set default date to today
  setRegDateToday();

  // Show modal
  document.getElementById('registryModal').style.display = 'flex';

  // Trigger async in-memory workbook warmup immediately so save is instant
  fetch(`/api/registry/warmup?excel_path=${encodeURIComponent(excelPath)}`, { method: 'POST' }).catch(() => {});

  // Load patient autocomplete database in background
  loadPatientsForAutocomplete(excelPath);

  // Load recent records and balance for selected sheet
  loadRegistryData();
}

function closeRegistryModal() {
  document.getElementById('registryModal').style.display = 'none';
  hideTypeahead();
}

async function loadPatientsForAutocomplete(excelPath) {
  try {
    const res = await fetch(`/api/registry/patients?excel_path=${encodeURIComponent(excelPath)}`);
    const data = await res.json();
    if (data.success && data.patients) {
      cachedPatients = data.patients;
    }
  } catch (err) {
    console.error('載入病患庫失敗:', err);
  }
}

async function onRegistrySheetChange() {
  loadRegistryData();
}

async function loadRegistryData() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('regSheetSelect').value;
  if (!excelPath || !sheetName) return;

  const tbody = document.getElementById('regRecentTableBody');
  tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding:15px; color:#888;">正在讀取該品項最新簿冊紀錄...</td></tr>';

  try {
    const res = await fetch(`/api/registry/records?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}&limit=12`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '讀取紀錄失敗');

    currentRegBalance = data.meta?.current_balance ?? 0;
    document.getElementById('regCurrentBal').textContent = currentRegBalance;

    updateRegistrySimulation();

    // Render recent records
    tbody.innerHTML = '';
    if (!data.records || data.records.length === 0) {
      tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding:15px; color:#888;">該藥品尚無交易紀錄</td></tr>';
      return;
    }

    data.records.forEach(r => {
      const tr = document.createElement('tr');
      const inStr = r.in_qty > 0 ? `<span class="text-success">+${r.in_qty}</span>` : '-';
      const outStr = r.out_qty > 0 ? `<span class="text-danger">-${r.out_qty}</span>` : '-';
      const balStr = r.balance < 0 ? `<span class="text-danger" style="font-weight:700;">${r.balance} ⚠️</span>` : `<strong>${r.balance}</strong>`;
      
      tr.innerHTML = `
        <td style="font-size:12px; color:#888;">${r.row_idx}</td>
        <td>${escapeHtml(r.date || '-')}</td>
        <td><span class="pill ${r.in_qty > 0 ? 'pill-ok' : 'pill-diff'}">${escapeHtml(r.reason || '-')}</span></td>
        <td class="text-right">${inStr}</td>
        <td>${escapeHtml(r.voucher || '-')}</td>
        <td class="text-right">${outStr}</td>
        <td class="text-right">${balStr}</td>
        <td><strong>${escapeHtml(r.person || '-')}</strong></td>
        <td style="font-size:12.5px; color:var(--ink-2);">${escapeHtml(r.note || '-')}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" class="text-center text-danger" style="padding:15px;">讀取失敗：${escapeHtml(err.message)}</td></tr>`;
  }
}

function updateRegistrySimulation() {
  const reason = document.getElementById('regReason').value;
  const qtyInput = document.getElementById('regQty');
  const qty = parseInt(qtyInput.value, 10) || 0;
  const alertArea = document.getElementById('regAlertArea');
  const statusBadge = document.getElementById('regStatusBadge');
  const simBalEl = document.getElementById('regSimBal');
  const submitBtn = document.getElementById('btnRegSubmit');

  let simBal = currentRegBalance;
  if (reason === '進貨' || reason === '退藥入庫') {
    simBal = currentRegBalance + qty;
  } else {
    simBal = currentRegBalance - qty;
  }

  simBalEl.textContent = simBal;

  if (simBal < 0) {
    simBalEl.style.color = 'var(--danger)';
    statusBadge.className = 'pill pill-diff';
    statusBadge.textContent = '⚠️ 透支警告 (結存<0)';
    alertArea.innerHTML = `
      <div class="alert-banner alert-danger" style="margin-bottom: 12px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
        <strong>法規防呆攔截：</strong> 目前庫存僅剩 ${currentRegBalance} 顆，扣除 ${qty} 顆後結存將變為負數 (${simBal})！系統已鎖定儲存按鈕，防止違反管制藥品管理條例。
      </div>
    `;
    submitBtn.disabled = true;
  } else {
    simBalEl.style.color = 'var(--accent)';
    statusBadge.className = 'pill pill-ok';
    statusBadge.textContent = '結存安全';
    alertArea.innerHTML = '';
    submitBtn.disabled = false;
  }
}

// ----------------------------------------------------
// Typeahead Autocomplete
// ----------------------------------------------------
function handleNameInput(e) {
  const val = e.target.value.trim().toLowerCase();
  const dropdown = document.getElementById('typeaheadDropdown');

  if (!val || val.length < 1 || cachedPatients.length === 0) {
    hideTypeahead();
    return;
  }

  const matches = cachedPatients.filter(p => {
    const matchName = (p.name || '').toLowerCase().includes(val);
    const matchId = (p.id || '').toLowerCase().includes(val);
    return matchName || matchId;
  }).slice(0, 8);

  if (matches.length === 0) {
    hideTypeahead();
    return;
  }

  dropdown.innerHTML = '';
  activeTypeaheadIndex = -1;

  matches.forEach((p, idx) => {
    const item = document.createElement('div');
    item.className = 'typeahead-item';
    item.dataset.index = idx;
    
    let metaStr = '';
    if (p.clinic) metaStr += ` ｜ ${p.clinic}`;
    if (p.doctor) metaStr += ` ｜ ${p.doctor}`;
    if (p.last_drug) metaStr += ` ｜ 常領: ${p.last_drug}`;

    item.innerHTML = `
      <div>
        <span class="typeahead-name">👤 ${escapeHtml(p.name)}</span>
        <span class="typeahead-id">${escapeHtml(p.id || '')}</span>
      </div>
      <div class="typeahead-meta">${escapeHtml(metaStr)}</div>
    `;

    item.addEventListener('mousedown', (ev) => {
      ev.preventDefault();
      selectPatient(p);
    });

    dropdown.appendChild(item);
  });

  dropdown.style.display = 'block';
}

function handleNameKeydown(e) {
  const dropdown = document.getElementById('typeaheadDropdown');
  if (dropdown.style.display !== 'block') return;

  const items = dropdown.querySelectorAll('.typeahead-item');
  if (items.length === 0) return;

  if (e.key === 'ArrowDown') {
    e.preventDefault();
    activeTypeaheadIndex = (activeTypeaheadIndex + 1) % items.length;
    highlightTypeaheadItem(items);
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    activeTypeaheadIndex = (activeTypeaheadIndex - 1 + items.length) % items.length;
    highlightTypeaheadItem(items);
  } else if (e.key === 'Enter') {
    if (activeTypeaheadIndex >= 0 && activeTypeaheadIndex < items.length) {
      e.preventDefault();
      items[activeTypeaheadIndex].dispatchEvent(new MouseEvent('mousedown'));
    }
  } else if (e.key === 'Escape') {
    hideTypeahead();
  }
}

function highlightTypeaheadItem(items) {
  items.forEach((it, idx) => {
    if (idx === activeTypeaheadIndex) {
      it.classList.add('selected');
      it.scrollIntoView({ block: 'nearest' });
    } else {
      it.classList.remove('selected');
    }
  });
}

function selectPatient(p) {
  document.getElementById('regName').value = p.name || '';
  document.getElementById('regId').value = p.id || '';
  if (p.doctor) {
    document.getElementById('regDoctor').value = p.doctor;
  } else if (p.clinic) {
    document.getElementById('regDoctor').value = p.clinic;
  }
  validateIdInput();
  hideTypeahead();
  document.getElementById('regQty').focus();
}

function hideTypeahead() {
  const dropdown = document.getElementById('typeaheadDropdown');
  if (dropdown) dropdown.style.display = 'none';
  activeTypeaheadIndex = -1;
}

document.addEventListener('click', (e) => {
  if (!e.target.closest('.typeahead-container')) {
    hideTypeahead();
  }
});

function validateIdInput() {
  const idVal = document.getElementById('regId').value.trim().toUpperCase();
  const badge = document.getElementById('idValidBadge');
  
  if (/^[A-Z][1289][0-9]{8}$/.test(idVal)) {
    badge.textContent = '✅ 身分證檢核通過';
    badge.className = 'pill pill-ok';
    badge.style.display = 'inline-block';
  } else if (/^[A-Z]{2}[0-9]{8}$/.test(idVal)) {
    badge.textContent = '✅ 居留證檢核通過';
    badge.className = 'pill pill-ok';
    badge.style.display = 'inline-block';
  } else if (idVal.length > 0) {
    badge.textContent = '⚠️ 格式未符標準';
    badge.className = 'pill pill-diff';
    badge.style.display = 'inline-block';
  } else {
    badge.style.display = 'none';
  }
}

// ----------------------------------------------------
// Submit & Revoke Transactions
// ----------------------------------------------------
async function submitRegistryTransaction() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('regSheetSelect').value;
  const date = document.getElementById('regDate').value.trim();
  const reason = document.getElementById('regReason').value;
  const qty = parseInt(document.getElementById('regQty').value, 10);
  const voucher = document.getElementById('regVoucher').value.trim();
  const name = document.getElementById('regName').value.trim();
  const idNum = document.getElementById('regId').value.trim().toUpperCase();
  const lot = document.getElementById('regLot').value.trim();
  const doctor = document.getElementById('regDoctor').value.trim();

  if (!excelPath || !sheetName) {
    alert('請選擇工作表！');
    return;
  }
  if (!date) {
    alert('請輸入登錄日期！');
    return;
  }
  if (isNaN(qty) || qty <= 0) {
    alert('異動數量必須為大於 0 之整數！');
    document.getElementById('regQty').focus();
    return;
  }

  // Deficit check
  if (reason !== '進貨' && reason !== '退藥入庫') {
    if (qty > currentRegBalance) {
      alert(`【結存不足】目前庫存僅剩 ${currentRegBalance} 顆，無法支出 ${qty} 顆！`);
      return;
    }
  }

  const btn = document.getElementById('btnRegSubmit');
  btn.disabled = true;
  btn.innerHTML = '⏳ 正在寫入 Excel 簿冊 (約需 3~4 秒)...';

  const alertArea = document.getElementById('regAlertArea');
  alertArea.innerHTML = '';

  try {
    const res = await fetch('/api/registry/append', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        excel_path: excelPath,
        sheet_name: sheetName,
        tx_data: {
          date: date,
          reason: reason,
          qty: qty,
          voucher: voucher,
          recipient_name: name,
          recipient_id: idNum,
          lot_number: lot,
          doctor_name: doctor
        }
      })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '寫入失敗');

    // Show success notification banner
    alertArea.innerHTML = `
      <div style="background: rgba(16, 185, 129, 0.12); border: 1px solid #10b981; color: #065f46; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; font-weight: 600; font-size: 13.5px; display: flex; justify-content: space-between; align-items: center;">
        <span>✅ 已成功寫入 Excel [${sheetName}] 第 ${data.row_idx} 列！目前結存更新為：${data.new_balance} 顆 (系統已同步產製防護快照)</span>
        <button onclick="document.getElementById('regAlertArea').innerHTML=''" style="border:none; background:transparent; font-size:16px; cursor:pointer; color:#065f46;">&times;</button>
      </div>
    `;

    // Update current balance chip immediately
    currentRegBalance = data.new_balance;
    document.getElementById('regCurrentBal').textContent = currentRegBalance;
    updateRegistrySimulation();

    // Instant DOM Prepend into Recent Table (zero network delay)
    const tbody = document.getElementById('regRecentTableBody');
    const tr = document.createElement('tr');
    tr.style.backgroundColor = 'rgba(16, 185, 129, 0.08)';
    const isIn = ['進貨', '退藥入庫', '盤盈'].includes(data.transaction.reason);
    const inCol = isIn ? `<td class="text-right text-success">+${data.transaction.qty}</td>` : `<td>-</td>`;
    const outCol = !isIn ? `<td class="text-right text-danger">-${data.transaction.qty}</td>` : `<td>-</td>`;
    tr.innerHTML = `
      <td>${data.row_idx}</td>
      <td>${escapeHtml(data.transaction.date)}</td>
      <td><span class="badge ${isIn ? 'badge-in' : 'badge-out'}">${escapeHtml(data.transaction.reason)}</span></td>
      ${inCol}
      <td>${escapeHtml(data.transaction.voucher || '-')}</td>
      ${outCol}
      <td class="text-right" style="font-weight: 700; color: var(--accent);">${data.transaction.balance}</td>
      <td>${escapeHtml(data.transaction.person || '-')}</td>
      <td style="color: #64748b; font-size: 12px;">${escapeHtml(data.transaction.note || '-')}</td>
    `;
    if (tbody.firstChild && tbody.firstChild.tagName === 'TR') {
      tbody.insertBefore(tr, tbody.firstChild);
    } else {
      tbody.innerHTML = '';
      tbody.appendChild(tr);
    }

    // Reset input fields
    document.getElementById('regQty').value = '';
    document.getElementById('regVoucher').value = '';
    document.getElementById('regName').value = '';
    document.getElementById('regId').value = '';
    document.getElementById('regLot').value = '';
    document.getElementById('regDoctor').value = '';
    document.getElementById('idValidBadge').style.display = 'none';

    // Focus back on patient name for lightning-fast next entry
    document.getElementById('regName').focus();

  } catch (err) {
    alertArea.innerHTML = `
      <div style="background: rgba(239, 68, 68, 0.12); border: 1px solid #ef4444; color: #991b1b; padding: 10px 14px; border-radius: 8px; margin-bottom: 12px; font-weight: 600; font-size: 13.5px;">
        ❌ 登錄寫入失敗：${escapeHtml(err.message)}
      </div>
    `;
  } finally {
    btn.disabled = false;
    btn.innerHTML = '💾 儲存並寫入 Excel 簿冊 (Ctrl+Enter)';
  }
}

async function revokeLastRegistryTransaction() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('regSheetSelect').value;
  if (!excelPath || !sheetName) return;

  if (!confirm(`確定要撤銷 [${sheetName}] 最後一筆登錄記錄嗎？\n此操作將從 Excel 刪除該列並秒級還原結存。`)) {
    return;
  }

  try {
    const res = await fetch('/api/registry/revoke', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        excel_path: excelPath,
        sheet_name: sheetName
      })
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '撤銷失敗');

    alert(`✅ 已成功撤銷最後一筆紀錄：\n${data.revoked_record}\n第 ${data.deleted_row} 列已清除！`);
    loadRegistryData();

  } catch (err) {
    alert('撤銷失敗：' + err.message);
  }
}

// ----------------------------------------------------
// Drug Management: Add, Edit, Delete Drugs in Ledger
// ----------------------------------------------------
async function reloadSheetSelectors(selectedSheet = null) {
  await onExcelFileChange();
  const sheetSelect = document.getElementById('sheetSelect');
  const regSheetSelect = document.getElementById('regSheetSelect');
  if (regSheetSelect) {
    regSheetSelect.innerHTML = '';
    Array.from(sheetSelect.options).forEach(opt => {
      if (opt.value) {
        const o = document.createElement('option');
        o.value = opt.value;
        o.textContent = opt.textContent;
        regSheetSelect.appendChild(o);
      }
    });
    if (selectedSheet) {
      regSheetSelect.value = selectedSheet;
      sheetSelect.value = selectedSheet;
    }
  }
}

function openAddDrugModal() {
  const excelPath = document.getElementById('excelSelect').value;
  if (!excelPath) {
    alert('請先在主畫面選擇或建立管制藥品登記簿冊 (Excel)');
    return;
  }
  document.getElementById('addDrugSheetName').value = '';
  document.getElementById('addDrugFullName').value = '';
  document.getElementById('addDrugLevel').value = '4';
  document.getElementById('addDrugUnit').value = '粒';
  document.getElementById('addDrugIngredient').value = '';
  document.getElementById('addDrugLicense').value = '';
  document.getElementById('addDrugManufacturer').value = '';
  document.getElementById('addDrugInitDate').value = '115/01/01';
  document.getElementById('addDrugInitBal').value = '0';
  document.getElementById('addDrugAlertArea').innerHTML = '';
  document.getElementById('addDrugModal').style.display = 'flex';
}

function closeAddDrugModal() {
  document.getElementById('addDrugModal').style.display = 'none';
}

async function submitAddDrug() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('addDrugSheetName').value.trim();
  const fullName = document.getElementById('addDrugFullName').value.trim();
  const level = document.getElementById('addDrugLevel').value;
  const unit = document.getElementById('addDrugUnit').value.trim() || '粒';
  const ingredient = document.getElementById('addDrugIngredient').value.trim();
  const license = document.getElementById('addDrugLicense').value.trim();
  const manufacturer = document.getElementById('addDrugManufacturer').value.trim();
  const initDate = document.getElementById('addDrugInitDate').value.trim() || '115/01/01';
  const initBal = parseInt(document.getElementById('addDrugInitBal').value, 10) || 0;

  const alertArea = document.getElementById('addDrugAlertArea');
  alertArea.innerHTML = '';

  if (!sheetName) {
    alertArea.innerHTML = '<div class="alert alert-danger" style="padding:8px 12px; margin-top:8px;">請輸入藥品分頁名稱（如：FM2 2MG）</div>';
    return;
  }

  try {
    const res = await fetch('/api/registry/drug/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        excel_path: excelPath,
        drug_info: {
          sheet_name: sheetName,
          drug_name: fullName || sheetName,
          control_level: level,
          unit: unit,
          ingredient: ingredient,
          license_no: license,
          manufacturer: manufacturer,
          initial_date: initDate,
          initial_balance: initBal
        }
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '新增失敗');

    closeAddDrugModal();
    await reloadSheetSelectors(data.sheet_name);
    loadRegistryData();

    const regAlert = document.getElementById('regAlertArea');
    regAlert.innerHTML = `
      <div class="alert alert-success" style="padding:10px 14px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;">
        <span>🎉 ${escapeHtml(data.message)}，已自動切換至該藥品分頁！</span>
        <button class="btn-close" onclick="this.parentElement.remove()">&times;</button>
      </div>
    `;
  } catch (err) {
    alertArea.innerHTML = `<div class="alert alert-danger" style="padding:8px 12px; margin-top:8px;">${escapeHtml(err.message)}</div>`;
  }
}

async function openEditDrugModal() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('regSheetSelect').value;
  if (!excelPath || !sheetName) {
    alert('請先選擇要修改的藥品分頁');
    return;
  }

  document.getElementById('editDrugAlertArea').innerHTML = '';
  try {
    const res = await fetch(`/api/registry/drug/info?excel_path=${encodeURIComponent(excelPath)}&sheet_name=${encodeURIComponent(sheetName)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '讀取藥品資訊失敗');

    document.getElementById('editDrugOldSheetName').value = data.sheet_name;
    document.getElementById('editDrugSheetName').value = data.sheet_name;
    document.getElementById('editDrugFullName').value = data.drug_name || '';
    document.getElementById('editDrugLevel').value = String(data.control_level || 4);
    document.getElementById('editDrugUnit').value = data.unit || '粒';
    document.getElementById('editDrugIngredient').value = data.ingredient || '';
    document.getElementById('editDrugLicense').value = data.license_no || '';
    document.getElementById('editDrugManufacturer').value = data.manufacturer || '';
    document.getElementById('editDrugInitBal').value = data.initial_balance ?? 0;

    document.getElementById('editDrugModal').style.display = 'flex';
  } catch (err) {
    alert('讀取藥品資訊失敗: ' + err.message);
  }
}

function closeEditDrugModal() {
  document.getElementById('editDrugModal').style.display = 'none';
}

async function submitEditDrug() {
  const excelPath = document.getElementById('excelSelect').value;
  const oldSheetName = document.getElementById('editDrugOldSheetName').value;
  const sheetName = document.getElementById('editDrugSheetName').value.trim();
  const fullName = document.getElementById('editDrugFullName').value.trim();
  const level = document.getElementById('editDrugLevel').value;
  const unit = document.getElementById('editDrugUnit').value.trim() || '粒';
  const ingredient = document.getElementById('editDrugIngredient').value.trim();
  const license = document.getElementById('editDrugLicense').value.trim();
  const manufacturer = document.getElementById('editDrugManufacturer').value.trim();
  const initBal = document.getElementById('editDrugInitBal').value.trim();

  const alertArea = document.getElementById('editDrugAlertArea');
  alertArea.innerHTML = '';

  if (!sheetName) {
    alertArea.innerHTML = '<div class="alert alert-danger" style="padding:8px 12px; margin-top:8px;">藥品分頁名稱不得為空</div>';
    return;
  }

  try {
    const res = await fetch('/api/registry/drug/edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        excel_path: excelPath,
        old_sheet_name: oldSheetName,
        new_drug_info: {
          sheet_name: sheetName,
          drug_name: fullName,
          control_level: level,
          unit: unit,
          ingredient: ingredient,
          license_no: license,
          manufacturer: manufacturer,
          initial_balance: initBal !== '' ? parseInt(initBal, 10) : ''
        }
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '更新失敗');

    closeEditDrugModal();
    await reloadSheetSelectors(data.sheet_name);
    loadRegistryData();

    const regAlert = document.getElementById('regAlertArea');
    regAlert.innerHTML = `
      <div class="alert alert-success" style="padding:10px 14px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;">
        <span>🎉 ${escapeHtml(data.message)}</span>
        <button class="btn-close" onclick="this.parentElement.remove()">&times;</button>
      </div>
    `;
  } catch (err) {
    alertArea.innerHTML = `<div class="alert alert-danger" style="padding:8px 12px; margin-top:8px;">${escapeHtml(err.message)}</div>`;
  }
}

async function confirmDeleteDrug() {
  const excelPath = document.getElementById('excelSelect').value;
  const sheetName = document.getElementById('regSheetSelect').value;
  if (!excelPath || !sheetName) return;

  if (!confirm(`⚠️ 警告：確定要刪除管制藥品分頁「${sheetName}」嗎？\n\n此操作將永久刪除該工作表內所有調劑進貨紀錄！（系統會在刪除前自動產生時間點備份快照）`)) {
    return;
  }

  try {
    const res = await fetch('/api/registry/drug/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        excel_path: excelPath,
        sheet_name: sheetName
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '刪除失敗');

    alert(`✅ ${data.message}`);
    await reloadSheetSelectors(data.next_sheet);
    loadRegistryData();
  } catch (err) {
    alert('刪除失敗: ' + err.message);
  }
}

function openCreateTemplateModal() {
  document.getElementById('newLedgerFilename').value = '115年度管制藥品收支結存簿.xlsx';
  document.getElementById('newLedgerPharmacy').value = '示範藥局';
  document.getElementById('createTemplateAlertArea').innerHTML = '';
  document.getElementById('createTemplateModal').style.display = 'flex';
}

function closeCreateTemplateModal() {
  document.getElementById('createTemplateModal').style.display = 'none';
}

async function submitCreateTemplate() {
  const filename = document.getElementById('newLedgerFilename').value.trim();
  const pharmacy = document.getElementById('newLedgerPharmacy').value.trim() || '示範藥局';
  const alertArea = document.getElementById('createTemplateAlertArea');
  alertArea.innerHTML = '';

  if (!filename) {
    alertArea.innerHTML = '<div class="alert alert-danger" style="padding:8px 12px;">請輸入檔案名稱</div>';
    return;
  }

  try {
    const res = await fetch('/api/registry/create-template', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        filename: filename,
        pharmacy_name: pharmacy
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '建立失敗');

    closeCreateTemplateModal();

    // Refresh excelSelect
    const excelSelect = document.getElementById('excelSelect');
    let opt = Array.from(excelSelect.options).find(o => o.value === data.path);
    if (!opt) {
      opt = document.createElement('option');
      opt.value = data.path;
      opt.textContent = `[新建立] ${data.filename} (${data.size})`;
      excelSelect.insertBefore(opt, excelSelect.firstChild);
    }
    excelSelect.value = data.path;
    await onExcelFileChange();

    alert(`🎉 成功建立全新管制藥品簿冊：\n${data.filename}\n已自動為您選取，隨時可開始登錄！`);
  } catch (err) {
    alertArea.innerHTML = `<div class="alert alert-danger" style="padding:8px 12px;">建立失敗：${escapeHtml(err.message)}</div>`;
  }
}

// Global hotkey: Ctrl+Enter to submit in registry modal
document.addEventListener('keydown', (e) => {
  const modal = document.getElementById('registryModal');
  if (modal && modal.style.display === 'flex') {
    if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      submitRegistryTransaction();
    } else if (e.key === 'Escape') {
      closeRegistryModal();
    }
  }
});

